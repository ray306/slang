TopoToolbox is an open-source software interface for topographic analysis on the event-related electrophysiological (EEG/MEG) data based on the method proposed by Tian and Huber (2008). TopoToolbox provides a tool for researchers to directly derive robust measures of response pattern (topographic) similarity and psychological meaningful response magnitude using electromagnetic signals in sensor space. These measures are useful for testing psychological theories without anatomical descriptions.

Three functions are provided in this toolbox:

1. Angle test: testing topographic similarity between experimental conditions

2. Projection test: normalizing individual difference against a template to measure response magnitude

3. Angle dynamics test: assessing pattern similarity over time

This toolbox is developed by Dr. Xing Tian, Dr. David Poeppel and Dr. David E. Huber. It requires MATLAB (The Mathworks, Inc.) environments and supports various of standard data format imported from EEGLAB as well as user defined dataset. Please cite the following references if you use the TopoToolbox for publications or public releases:

Tian, X., & Huber, D. (2008). Measures of spatial similarity and response magnitude in MEG and scalp EEG. Brain Topography, 20(3), 131-141.

Tian, X., Poeppel, D., & Huber, D.E. (2011) TopoToolbox: Using sensor topography to calculate psychologically meaningful measures from event-related EEG/MEG. Computational Intelligence and Neuroscience, 2011. doi:10.1155/2011/674605

Should you have any questions or comments regarding this toolbox, please contact me. Email: xing.tian@nyu.edu


***************
Notes on sample data:

The 'samples' folder includes two subfolders, one for individual analysis and another for group analysis. In each subfolders, there are data from two studies ('PRMT' for the function of Angle test and Projection test; 'Motor' for the function of Angle dynamics). 

Because of the space capacitiy limits, Only 1 participant's data with 4 trials were included in the folder 'data for_individual_analysis' of each study just for demonstration of individual analysis. All indivudial participants' results were calculated using individual analysis and ready for group analysis (in the folder of 'data for_group_analysis').  