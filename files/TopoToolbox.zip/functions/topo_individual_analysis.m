function varargout = topo_individual_analysis(varargin)

% TOPO_INDIVIDUAL_ANALYSIS M-file for topo_individual_analysis.fig
%      TOPO_INDIVIDUAL_ANALYSIS, by itself, creates a new TOPO_INDIVIDUAL_ANALYSIS or raises the existing
%      singleton*.
%
%      H = TOPO_INDIVIDUAL_ANALYSIS returns the handle to a new TOPO_INDIVIDUAL_ANALYSIS or the handle to
%      the existing singleton*.
%
%      TOPO_INDIVIDUAL_ANALYSIS('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in TOPO_INDIVIDUAL_ANALYSIS.M with the given input arguments.
%
%      TOPO_INDIVIDUAL_ANALYSIS('Property','Value',...) creates a new TOPO_INDIVIDUAL_ANALYSIS or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before topo_individual_analysis_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to topo_individual_analysis_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help topo_individual_analysis

% Last Modified by GUIDE v2.5 29-Aug-2010 19:32:49

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
    'gui_Singleton',  gui_Singleton, ...
    'gui_OpeningFcn', @topo_individual_analysis_OpeningFcn, ...
    'gui_OutputFcn',  @topo_individual_analysis_OutputFcn, ...
    'gui_LayoutFcn',  [] , ...
    'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before topo_individual_analysis is made visible.
function topo_individual_analysis_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to topo_individual_analysis (see VARARGIN)

% Choose default command line output for topo_individual_analysis
handles.output = hObject;

%pixels
set( hObject, ...
    'Units', 'pixels' );

%get your display size
screenSize = get(0, 'ScreenSize');

%calculate the center of the display
position = get( hObject, ...
    'Position' );
position(1) = (screenSize(3)-position(3))/2;
position(2) = (screenSize(4)-position(4))/2;

set(hObject,'Resize','On');

%center the window
set( hObject, ...
    'Position', position );

% Update handles structure
guidata(hObject, handles);

setguiasopening(hObject);


% UIWAIT makes topo_individual_analysis wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = topo_individual_analysis_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


function setguiasopening(hObject)
%%%%initiating new handles
handles = guidata(hObject);

handles.filenamelist1={};        % list of name of files for template
handles.pathnamelist1={};        % list of path to files for template
handles.filenamelist2={};        % list of name of files for experimental
handles.pathnamelist2={};        % list of path to files for experimental

handles.rec1 ={};                % list to record the number of files
handles.rec2 ={};                % list to record the number of files

handles.load1_data_all = [];     % reset all loaded data
handles.load2_data_all = [];

%%%%reset file selections
set(handles.load1_filename_list,'String',handles.filenamelist1);
set(handles.load2_filename_list,'String',handles.filenamelist2);

%%%%initiating to-be-recorded variables
handles.sf = [];
handles.pre = [];
handles.post = [];
handles.within_cos_angle = [];
handles.betwen_cos_angle = [];
handles.template_latency = [];
handles.exp_latency = [];
handles.projection_exp = [];
handles.half_window_width_value = [];
handles.channel_selection_num = [];

handles.ch_pathname = {};
handles.ch_filename = {};
handles.ch_config = [];
handles.EEG_indicator = [];


%%%%initiate object appearance values
set(handles.load1_filename_list,'Value',0);
set(handles.load2_filename_list,'Value',0);
set(handles.channel_selection,'Value',1);
set(handles.baseline_correction_1,'Value',0);
set(handles.baseline_correction_2,'Value',0);
set(handles.current_time_load1,'String','0');
set(handles.current_time_load2,'String','0');
set(handles.latency1,'String','0');
set(handles.latency2,'String','0');
set(handles.latency3,'String','0');
set(handles.latency4,'String','0');
set(handles.latency5,'String','0');
set(handles.latency6,'String','0');
set(handles.latency7,'String','0');
set(handles.iteration_number,'String','iterations number');
set(handles.half_window_width,'String','0');
set(handles.half_half_indicator,'Value',1);
set(handles.interleaved_indicator,'Value',0);
set(handles.random_indicator,'Value',0);
set(handles.iteration_number,'String','0');

set(handles.sampling_frequency,'String','HZ');
set(handles.pre_trigger_time,'String','in ms');
set(handles.post_trigger_time,'String','in ms');

set(handles.half_window_width,'String','in ms');

set(handles.imp_ch_config,'Value',0);

set(handles.half_half_indicator,'Value',1);
set(handles.interleaved_indicator,'Value',0);
set(handles.random_indicator,'Value',0);
set(handles.iteration_number,'String','0');

%%%%recording initial parameters
handles.angle_test_value = get(handles.angle_test,'Value');
handles.projection_test_value = get(handles.projection_test,'Value');
handles.angle_dynamics_value = get(handles.angle_dynamics,'Value');

handles.load1_string = get(handles.load1,'String');
handles.load2_string = get(handles.load2,'String');

handles.channel_selection_string = get(handles.channel_selection,'String');
handles.channel_selection_value = get(handles.channel_selection,'Value');

handles.plot_time1 = str2num(get(handles.current_time_load1,'String'));
handles.plot_time2 = str2num(get(handles.current_time_load2,'String'));

%%%%initiating display
%%%%common in 3 functions
set(handles.back_step1_load1,'Visible','off');
set(handles.back_step2_load1,'Visible','off');
set(handles.back_step3_load1,'Visible','off');
set(handles.back_step1_load2,'Visible','off');
set(handles.back_step2_load2,'Visible','off');
set(handles.back_step3_load2,'Visible','off');

set(handles.forward_step1_load1,'Visible','off');
set(handles.forward_step2_load1,'Visible','off');
set(handles.forward_step3_load1,'Visible','off');
set(handles.forward_step1_load2,'Visible','off');
set(handles.forward_step2_load2,'Visible','off');
set(handles.forward_step3_load2,'Visible','off');

set(handles.current_time_load1,'Visible','off');
set(handles.current_time_load2,'Visible','off');

set(handles.axes1,'Visible','off');
set(handles.axes2,'Visible','off');
set(handles.axes3,'Visible','off');
set(handles.topoplot1,'Visible','off');
set(handles.topoplot2,'Visible','off');


axes(handles.axes1);
cla;
axes(handles.axes2);
cla;
axes(handles.axes3);
legend(handles.axes3,'off')
cla;
axes(handles.topoplot1);
cla;
axes(handles.topoplot2);
cla;

set(handles.latency1_text,'Visible','off');
set(handles.latency1,'Visible','off');
set(handles.latency2_text,'Visible','off');
set(handles.latency2,'Visible','off');
set(handles.latency3_text,'Visible','off');
set(handles.latency3,'Visible','off');
set(handles.latency4_text,'Visible','off');
set(handles.latency4,'Visible','off');
set(handles.latency5_text,'Visible','off');
set(handles.latency5,'Visible','off');
set(handles.latency6_text,'Visible','off');
set(handles.latency6,'Visible','off');
set(handles.latency7_text,'Visible','off');
set(handles.latency7,'Visible','off');

set(handles.half_window_width_text,'Visible','off');
set(handles.half_window_width,'Visible','off');

set(handles.iteration_number,'Visible','off');

set(handles.null_gen_panel,'Visible','off');
set(handles.gen_button,'Visible','off');
set(handles.save_button,'Visible','off');


%%%%set for specific function
if handles.angle_test_value == 1
    handles.load1_string{1} = 'Load experimental file1';
    handles.load2_string{1} = 'Load experimental file2';
    
    handles.avg1_text_string = {'average response of condition 1'};
    handles.avg2_text_string = {'average response of condition 2'};
    
    handles.latency1_text_string = {'response latency in condition 1'};
    handles.latency2_text_string = {'response latency in condition 2'};
    
    handles.gen_button_string = {'generating angle measure'};
    
    handles.results_panel_string = {'Angle measure'};
    
elseif handles.projection_test_value == 1
    handles.load1_string{1} = 'Load template file';
    handles.load2_string{1} = 'Load experimental file';
    
    handles.avg1_text_string = {'average response of template'};
    handles.avg2_text_string = {'average response of condition 1'};
    
    handles.latency1_text_string = {'response latency in template'};
    handles.latency2_text_string = {'response latency in condition 1'};
    
    handles.gen_button_string = {'generating projection value waveform'};
    
    handles.results_panel_string = {'Projection value'};
    
elseif handles.angle_dynamics_value == 1
    handles.load1_string{1} = 'Load template file';
    handles.load2_string{1} = 'Load experimental file';
    
    handles.avg1_text_string = {'average response of template'};
    handles.avg2_text_string = {'average response of condition 1'};
    
    handles.latency1_text_string = {'response latency in template'};
    handles.latency2_text_string = {'response latency in condition 1'};
    
    handles.gen_button_string = {'generating angle measure waveform'};
    
    handles.results_panel_string = {'Angle measure'};
    
end

set(handles.load1,'String',handles.load1_string);
set(handles.load2,'String',handles.load2_string);

set(handles.avg1_text,'String',handles.avg1_text_string);
set(handles.avg2_text,'String',handles.avg2_text_string);

set(handles.latency1_text,'String',handles.latency1_text_string);
set(handles.latency2_text,'String',handles.latency2_text_string);

set(handles.gen_button,'String',handles.gen_button_string);

set(handles.results_panel,'Title',handles.results_panel_string);

guidata(hObject,handles);


function pre_trigger_time_Callback(hObject, eventdata, handles)
% hObject    handle to pre_trigger_time (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of pre_trigger_time as text
%        str2double(get(hObject,'String')) returns contents of pre_trigger_time as a double

handles.pre = str2num(get(handles.pre_trigger_time,'String'))*handles.sf/1000;

guidata(hObject, handles);



% --- Executes during object creation, after setting all properties.
function pre_trigger_time_CreateFcn(hObject, eventdata, handles)
% hObject    handle to pre_trigger_time (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function post_trigger_time_Callback(hObject, eventdata, handles)
% hObject    handle to post_trigger_time (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of post_trigger_time as text
%        str2double(get(hObject,'String')) returns contents of post_trigger_time as a double

handles.post = str2num(get(handles.post_trigger_time,'String'))*handles.sf/1000;

guidata(hObject, handles);



% --- Executes during object creation, after setting all properties.
function post_trigger_time_CreateFcn(hObject, eventdata, handles)
% hObject    handle to post_trigger_time (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function latency2_Callback(hObject, eventdata, handles)
% hObject    handle to latency2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of latency2 as text
%        str2double(get(hObject,'String')) returns contents of latency2 as a double

handles.latency_time2 = str2num(get(handles.latency2,'String'));

guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function latency2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to latency2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function half_window_width_Callback(hObject, eventdata, handles)
% hObject    handle to half_window_width (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of half_window_width as text
%        str2double(get(hObject,'String')) returns contents of half_window_width as a double

handles.half_window_width_value = str2num(get(handles.half_window_width,'String'));

guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function half_window_width_CreateFcn(hObject, eventdata, handles)
% hObject    handle to half_window_width (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in gen_button.
function gen_button_Callback(hObject, eventdata, handles)
% hObject    handle to gen_button (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

if handles.angle_test_value == 1
    angle_test_calculation(hObject, eventdata, handles);
elseif handles.projection_test_value == 1
    projection_test_calculation(hObject, eventdata, handles);
elseif handles.angle_dynamics_value == 1
    angle_dynamics_calculation(hObject, eventdata, handles);
end

set(handles.axes3,'Visible','on');

%%%%internal function for calculating angle similarity
function angle_test_calculation(hObject, eventdata, handles)
load1_filename_list = get(handles.load1_filename_list,'String');
load2_filename_list = get(handles.load2_filename_list,'String');
load1_filename_value = get(handles.load1_filename_list,'value');
load2_filename_value = get(handles.load2_filename_list,'value');

%%%%load in data
eval(['exp1_data = handles.load1_data_all.file',num2str(load1_filename_value),';'])
eval(['exp2_data = handles.load2_data_all.file',num2str(load2_filename_value),';'])

%%%%channel selection
if handles.channel_selection_value == 3
    exp1_data = exp1_data(handles.channel_selection_num,:,:);
    exp2_data = exp2_data(handles.channel_selection_num,:,:);
end

%%%%loading timing parameters
handles.latency_time1 = round(str2num(get(handles.latency1,'String'))*handles.sf/1000);
handles.latency_time2 = round(str2num(get(handles.latency2,'String'))*handles.sf/1000);
handles.exp_latency = handles.latency_time1; %%%%moving exp_data2 align with exp_data1
handles.half_window_width_value = round(str2num(get(handles.half_window_width,'String'))*handles.sf/1000);

%%%%align the second experimental condition to the first one
%%%%%%%%moving exp_data2 align with exp_data1
diff_time = round(handles.latency_time1 - handles.latency_time2);
if diff_time >0
    %exp2_data = cat(2,zeros(size(exp2_data,1),diff_time,size(exp2_data,3)),exp2_data);
    exp2_data = cat(2,ones(size(exp2_data,1),diff_time,size(exp2_data,3)),exp2_data);
    exp2_data = exp2_data(:,1:size(exp1_data,2),:);
elseif diff_time < 0
    %exp2_data = cat(2,exp2_data,zeros(size(exp2_data,1),abs(diff_time),size(exp2_data,3)));
    exp2_data = cat(2,exp2_data,ones(size(exp2_data,1),abs(diff_time),size(exp2_data,3)));
    exp2_data = exp2_data(:,(abs(diff_time)+1):size(exp2_data,2),:);
end

%%%%the way of creating halves
half_half_indicator = get(handles.half_half_indicator,'Value');
interleaved_indicator = get(handles.interleaved_indicator,'Value');
random_indicator = get(handles.random_indicator,'Value');

if random_indicator == 1
    for repeat_time = 1:str2num(get(handles.iteration_number,'String'))
        tempindex = randperm(size(exp1_data,3));
        separate_indicator1 = tempindex(1:round(size(exp1_data,3)/2));
        separate_indicator2 = tempindex(round(size(exp1_data,3)/2)+1:end);
        
        [within_cos_angle_one_iter, between_cos_angle_one_iter] = SCC_calculation(hObject,eventdata,handles,exp1_data,exp2_data,separate_indicator1,separate_indicator2);
        
        within_cos_angle_rep(:,:,repeat_time) = within_cos_angle_one_iter;
        between_cos_angle_rep(:,:,repeat_time) = between_cos_angle_one_iter;
    end
    %%%%average within define time window
    within_cos_angle_time = mean(within_cos_angle_rep(:,[handles.pre+handles.exp_latency-handles.half_window_width_value:handles.pre+handles.exp_latency+handles.half_window_width_value],:),2);
    between_cos_angle_time = mean(between_cos_angle_rep(:,[handles.pre+handles.exp_latency-handles.half_window_width_value:handles.pre+handles.exp_latency+handles.half_window_width_value],:),2);
%     within_cos_angle_time = mean(within_cos_angle_rep(:,[handles.pre+handles.exp_latency-handles.half_window_width_value handles.pre+handles.exp_latency+handles.half_window_width_value],:),2);
%     between_cos_angle_time = mean(between_cos_angle_rep(:,[handles.pre+handles.exp_latency-handles.half_window_width_value handles.pre+handles.exp_latency+handles.half_window_width_value],:),2);
    within_cos_angle = squeeze(mean(within_cos_angle_time,3));
    between_cos_angle = squeeze(mean(between_cos_angle_time,3));
    within_cos_angle_sem = std(within_cos_angle_time,1,3)./sqrt(str2num(get(handles.iteration_number,'String')));
    between_cos_angle_sem = std(between_cos_angle_time,1,3)./sqrt(str2num(get(handles.iteration_number,'String')));
    
    axes(handles.axes3);
    bar([within_cos_angle;between_cos_angle]);
    set(gca,'XTickLabel',{'within_angle_measure';'between_angle_measure'})
    hold on;
    errorbar([within_cos_angle;between_cos_angle],[within_cos_angle_sem;between_cos_angle_sem],'+k','MarkerSize',1);
    hold off;
    ylabel('Angle measure');
    
else
    
    if half_half_indicator == 1
        separate_indicator1 = [1:1:round(size(exp1_data,3)/2)];
        separate_indicator2 = [round(size(exp1_data,3)/2)+1:1:size(exp1_data,3)];
    elseif interleaved_indicator == 1
        separate_indicator1 = [1:2:size(exp1_data,3)];
        separate_indicator2 = [2:2:size(exp1_data,3)];
    end
    
    [within_cos_angle_time, between_cos_angle_time] = SCC_calculation(hObject,eventdata,handles,exp1_data,exp2_data,separate_indicator1,separate_indicator2);
    
    within_cos_angle = mean(within_cos_angle_time(:,[handles.pre+handles.exp_latency-handles.half_window_width_value:handles.pre+handles.exp_latency+handles.half_window_width_value],:),2);
    between_cos_angle = mean(between_cos_angle_time(:,[handles.pre+handles.exp_latency-handles.half_window_width_value:handles.pre+handles.exp_latency+handles.half_window_width_value],:),2);
%     within_cos_angle = mean(within_cos_angle_time(:,[handles.pre+handles.exp_latency-handles.half_window_width_value handles.pre+handles.exp_latency+handles.half_window_width_value],:),2);
%     between_cos_angle = mean(between_cos_angle_time(:,[handles.pre+handles.exp_latency-handles.half_window_width_value handles.pre+handles.exp_latency+handles.half_window_width_value],:),2);
    
    axes(handles.axes3);
    bar([within_cos_angle;between_cos_angle]);
    set(gca,'XTickLabel',{'within_angle_measure';'between_angle_measure'})
    ylabel('Angle measure');
end

handles.within_cos_angle = within_cos_angle;
handles.between_cos_angle = between_cos_angle;

guidata(hObject, handles);

%%%%internal function for calculating angle measure in function of angle_test_calculation
function [within_SCC,between_SCC] = SCC_calculation(hObject,eventdata,handles,exp1_data,exp2_data,separate_indicator1,separate_indicator2);
%%%%creating two parts of average data
first_exp1_avg = mean(exp1_data(:,:,separate_indicator1),3);
second_exp1_avg = mean(exp1_data(:,:,separate_indicator2),3);
first_exp2_avg = mean(exp2_data(:,:,separate_indicator1),3);
second_exp2_avg = mean(exp2_data(:,:,separate_indicator2),3);
%%baseline correction
if get(handles.baseline_correction_1,'Value') == 1
    first_exp1_avg = first_exp1_avg - mean(first_exp1_avg(:,[1:handles.pre]),2)*ones(1,size(first_exp1_avg,2));
    second_exp1_avg = second_exp1_avg - mean(second_exp1_avg(:,[1:handles.pre]),2)*ones(1,size(second_exp1_avg,2));
end
if get(handles.baseline_correction_2,'Value') == 1
    first_exp2_avg = first_exp2_avg - mean(first_exp2_avg(:,[1:handles.pre]),2)*ones(1,size(first_exp2_avg,2));
    second_exp2_avg = second_exp2_avg - mean(second_exp2_avg(:,[1:handles.pre]),2)*ones(1,size(second_exp2_avg,2));
end

%%%%calculating the cosine value of 'within angle' ('within-angle-measure): null hypothesis
within1 = sum(first_exp1_avg.*second_exp1_avg,1)./(sqrt(sum(first_exp1_avg.^2,1)).*sqrt(sum(second_exp1_avg.^2,1)));
within2 = sum(first_exp2_avg.*second_exp2_avg,1)./(sqrt(sum(first_exp2_avg.^2,1)).*sqrt(sum(second_exp2_avg.^2,1)));
within_SCC = (within1+within2)./2;

%%%%calculating the cosine value of 'between angle'('between-angle-measure)
between1 = sum(first_exp1_avg.*second_exp2_avg,1)./(sqrt(sum(first_exp1_avg.^2,1)).*sqrt(sum(second_exp2_avg.^2,1)));
between2 = sum(first_exp2_avg.*second_exp1_avg,1)./(sqrt(sum(first_exp2_avg.^2,1)).*sqrt(sum(second_exp1_avg.^2,1)));
between_SCC = (between1+between2)./2;



%%%%internal function for calculating projection value
function projection_test_calculation(hObject, eventdata, handles)

load1_filename_list = get(handles.load1_filename_list,'String');
load2_filename_list = get(handles.load2_filename_list,'String');
load1_filename_value = get(handles.load1_filename_list,'value');
load2_filename_value = get(handles.load2_filename_list,'value');

%%%%loading in data
eval(['template_data = handles.load1_data_all.file',num2str(load1_filename_value),';'])
exp_data = handles.load2_data_all;

%%%%channel selection
if handles.channel_selection_value == 3
    template_data = template_data(handles.channel_selection_num,:,:);
    for i = 1:length(load2_filename_list)
        eval(['exp_data.file',num2str(i),' = exp_data.file',num2str(i),'(handles.channel_selection_num,:,:);'])
    end
end

%%%%loading timing parameters
handles.latency_time1 = round(str2num(get(handles.latency1,'String'))*handles.sf/1000);
handles.latency_time2 = round(str2num(get(handles.latency2,'String'))*handles.sf/1000);
handles.latency_time3 = round(str2num(get(handles.latency3,'String'))*handles.sf/1000);
handles.latency_time4 = round(str2num(get(handles.latency4,'String'))*handles.sf/1000);
handles.latency_time5 = round(str2num(get(handles.latency5,'String'))*handles.sf/1000);
handles.latency_time6 = round(str2num(get(handles.latency6,'String'))*handles.sf/1000);
handles.latency_time7 = round(str2num(get(handles.latency7,'String'))*handles.sf/1000);

%%%%obtaining average files
avg_template = mean(template_data,3);
for i = 1:length(load2_filename_list)
    eval(['avg_exp.file',num2str(i),' = mean(exp_data.file',num2str(i),',3);'])
end

%%baseline correction
if get(handles.baseline_correction_1,'Value') == 1
    avg_template = baseline_correction(hObject, eventdata, handles,avg_template);
end

if get(handles.baseline_correction_2,'Value') == 1
    for i = 1:length(load2_filename_list)
        eval(['avg_exp.file',num2str(i),' = baseline_correction(hObject, eventdata, handles, avg_exp.file',num2str(i),');'])
    end
end

%%%%calculating exp projection value after porjecting on the template,
%%%%normalized by the magnitude of template
for i = 1:length(load2_filename_list)
    avg_template_transpose = avg_template';
    eval(['projection_exp.file',num2str(i),' = (avg_template_transpose(handles.pre+handles.latency_time1,:)*avg_exp.file',num2str(i),')./sum(avg_template_transpose(handles.pre+handles.latency_time1,:).^2,2);'])
end

axes(handles.axes3);
t = [-handles.pre*1000/handles.sf:1000/handles.sf:(handles.post)*1000/handles.sf];
colorlist = {'y','r','b','k','c','g'};
for i = 1:length(load2_filename_list)
    eval(['plot(t,projection_exp.file',num2str(i),',colorlist{i});'])
    hold on;
end
hold off;
legend_name = {'condition1','condition2','condition3','condition4','condition5','condition6'};
legend(legend_name{1:length(load2_filename_list)});
xlabel('Time (ms)');
ylabel('Projection value');

handles.projection_exp = projection_exp;
handles.template_latency = handles.latency_time1;
for i = 1:length(load2_filename_list)
    eval(['handles.exp_latency.con',num2str(i),' = handles.latency_time',num2str(i+1),';'])
end

guidata(hObject, handles);

%%%%internal function for calculating angle dynamics
function angle_dynamics_calculation(hObject, eventdata, handles)
load1_filename_list = get(handles.load1_filename_list,'String');
load2_filename_list = get(handles.load2_filename_list,'String');
load1_filename_value = get(handles.load1_filename_list,'value');
load2_filename_value = get(handles.load2_filename_list,'value');

%%%%loading in data
eval(['template_data = handles.load1_data_all.file',num2str(load1_filename_value),';'])
eval(['experimental_data = handles.load2_data_all.file',num2str(load2_filename_value),';'])

%%%%channel selection
if handles.channel_selection_value == 3
    template_data = template_data(handles.channel_selection_num,:,:);
    experimental_data = experimental_data(handles.channel_selection_num,:,:);
end

% %%%%loading timing parameters
handles.latency_time1 = round(str2num(get(handles.latency1,'String'))*handles.sf/1000);
handles.latency_time2 = round(str2num(get(handles.latency2,'String'))*handles.sf/1000);

%%%%the way of creating halves
half_half_indicator = get(handles.half_half_indicator,'Value');
interleaved_indicator = get(handles.interleaved_indicator,'Value');
random_indicator = get(handles.random_indicator,'Value');

if random_indicator == 1
    for repeat_time = 1:str2num(get(handles.iteration_number,'String'))
        tempindex = randperm(size(template_data,3));
        separate_indicator1 = tempindex(1:round(size(template_data,3)/2));
        separate_indicator2 = tempindex(round(size(template_data,3)/2)+1:end);
        
        [within1_SCC, within2_SCC, between_cos_angle_one_iter] = SCC_calculation_angle_dynamics(hObject,eventdata,handles,template_data,experimental_data,separate_indicator1,separate_indicator2);
        
        within_cos_angle1_rep(:,:,repeat_time) = within1_SCC;
        within_cos_angle2_rep(:,:,repeat_time) = within2_SCC;
        between_cos_angle_rep(:,:,repeat_time) = between_cos_angle_one_iter;
    end
    %within_cos_angle = mean(within_cos_angle_rep,3);
    within1_SCC = mean(within_cos_angle1_rep,3);
    within2_SCC = mean(within_cos_angle2_rep,3);
    between_cos_angle = mean(between_cos_angle_rep,3);
    %within_cos_angle_sem = std(within_cos_angle_rep,1,3)./sqrt(str2num(get(handles.iteration_number,'String')));
    between_cos_angle_sem = std(between_cos_angle_rep,1,3)./sqrt(str2num(get(handles.iteration_number,'String')));
    
    axes(handles.axes3);
    t = [-handles.pre*1000/handles.sf:1000/handles.sf:(handles.post)*1000/handles.sf];
    plot(t,between_cos_angle,'r');
    axis([min(t) max(t) -inf inf])
    hold on;
    for counter = 1:size(between_cos_angle,2)
        line([counter*1000/handles.sf-handles.pre*1000/handles.sf counter*1000/handles.sf-handles.pre*1000/handles.sf],[between_cos_angle(:,counter)-between_cos_angle_sem(:,counter) between_cos_angle(:,counter)+between_cos_angle_sem(:,counter)],'Color','g');
    end
    plot(t,between_cos_angle,'r');
    axis([min(t) max(t) -inf inf])
    legend('between angle measure');
    hold off
    xlabel('Time (ms)');
    ylabel('Angle measure');
    
else
    
    if half_half_indicator == 1
        separate_indicator1 = [1:1:round(size(template_data,3)/2)];
        separate_indicator2 = [round(size(template_data,3)/2)+1:1:size(template_data,3)];
    elseif interleaved_indicator == 1
        separate_indicator1 = [1:2:size(template_data,3)];
        separate_indicator2 = [2:2:size(template_data,3)];
    end
    
    [within1_SCC, within2_SCC, between_cos_angle] = SCC_calculation_angle_dynamics(hObject,eventdata,handles,template_data,experimental_data,separate_indicator1,separate_indicator2);
    
    axes(handles.axes3);
    t = [-handles.pre*1000/handles.sf:1000/handles.sf:(handles.post)*1000/handles.sf];
    plot(t,between_cos_angle,'r');
    legend('between angle measure');
    axis([min(t) max(t) -inf inf])
    xlabel('Time (ms)');
    ylabel('Angle measure');
end

handles.within_cos_angle1 = within1_SCC;
handles.within_cos_angle2 = within2_SCC;
handles.between_cos_angle = between_cos_angle;

handles.template_latency = handles.latency_time1;
handles.exp_latency = handles.latency_time2;

guidata(hObject, handles);


%%%%internal function for calculating angle measure in the function of angle_dynamics_calculation
function [within1_SCC, within2_SCC, between_cos_angle] = SCC_calculation_angle_dynamics(hObject,eventdata,handles,template_data,experimental_data,separate_indicator1,separate_indicator2)
%%%%creating two parts of average data
first_template_avg = mean(template_data(:,:,separate_indicator1),3);
second_template_avg = mean(template_data(:,:,separate_indicator2),3);
first_experimental_avg = mean(experimental_data(:,:,separate_indicator1),3);
second_experimental_avg = mean(experimental_data(:,:,separate_indicator2),3);
%%baseline correction
if get(handles.baseline_correction_1,'Value') == 1
    first_template_avg = first_template_avg - mean(first_template_avg(:,[1:handles.pre]),2)*ones(1,size(first_template_avg,2));
    second_template_avg = second_template_avg - mean(second_template_avg(:,[1:handles.pre]),2)*ones(1,size(second_template_avg,2));
end
if get(handles.baseline_correction_2,'Value') == 1
    first_experimental_avg = first_experimental_avg - mean(first_experimental_avg(:,[1:handles.pre]),2)*ones(1,size(first_experimental_avg,2));
    second_experimental_avg = second_experimental_avg - mean(second_experimental_avg(:,[1:handles.pre]),2)*ones(1,size(second_experimental_avg,2));
end

%%%%calculating the cosine value of 'within angle' ('within-angle-measure): null hypothesis
within1_SCC = sum(first_template_avg.*second_template_avg,1)./(sqrt(sum(first_template_avg.^2,1)).*sqrt(sum(second_template_avg.^2,1)));
within2_SCC = sum(first_experimental_avg.*second_experimental_avg,1)./(sqrt(sum(first_experimental_avg.^2,1)).*sqrt(sum(second_experimental_avg.^2,1)));
%within_cos_angle = (within1+within2)./2;

%%%%calculating the cosine value of 'between angle'('between-angle-measure)
between1 = (second_template_avg(:,handles.pre+handles.latency_time1)'*first_experimental_avg)./(sqrt(sum(second_template_avg(:,handles.pre+handles.latency_time1).^2,1)).*sqrt(sum(first_experimental_avg.^2,1)));
between2 = (first_template_avg(:,handles.pre+handles.latency_time1)'*second_experimental_avg)./(sqrt(sum(first_template_avg(:,handles.pre+handles.latency_time1).^2,1)).*sqrt(sum(second_experimental_avg.^2,1)));
between_cos_angle = (between1+between2)./2;


function latency1_Callback(hObject, eventdata, handles)
% hObject    handle to latency1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of latency1 as text
%        str2double(get(hObject,'String')) returns contents of latency1 as a double

handles.latency_time1 = str2num(get(handles.latency1,'String'));

guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function latency1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to latency1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in gen_avg_plot.
function gen_avg_plot_Callback(hObject, eventdata, handles)
% hObject    handle to gen_avg_plot (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

load1_filename_value = get(handles.load1_filename_list,'value');
load2_filename_value = get(handles.load2_filename_list,'value');

%%%%selecting 2 data to plot
eval(['handles.load1_data_orig = handles.load1_data_all.file',num2str(load1_filename_value),';'])
eval(['handles.load2_data_orig = handles.load2_data_all.file',num2str(load2_filename_value),';'])

%%%%obtaining average template file
handles.avg_load1_orig = mean(handles.load1_data_orig,3);
handles.avg_load1 = handles.avg_load1_orig;
handles.RMS_avg_load1 = sqrt(mean(handles.avg_load1.^2,1));

handles.avg_load2_orig = mean(handles.load2_data_orig,3);
handles.avg_load2 = handles.avg_load2_orig;
handles.RMS_avg_load2 = sqrt(mean(handles.avg_load2.^2,1));

guidata(hObject, handles);

%%%%baseline correction
if get(handles.baseline_correction_1,'Value') == 1
    handles.avg_load1 = baseline_correction(hObject, eventdata, handles, handles.avg_load1);
    handles.RMS_avg_load1 = sqrt(mean(handles.avg_load1.^2,1));
end

if get(handles.baseline_correction_2,'Value') == 1
    handles.avg_load2 = baseline_correction(hObject, eventdata, handles, handles.avg_load2);
    handles.RMS_avg_load2 = sqrt(mean(handles.avg_load2.^2,1));
end

set(handles.current_time_load1,'String',num2str(0));
set(handles.current_time_load2,'String',num2str(0));

waveform_plot(hObject, eventdata, handles,handles.axes1,0,handles.avg_load1,handles.RMS_avg_load1);
waveform_plot(hObject, eventdata, handles,handles.axes2,0,handles.avg_load2,handles.RMS_avg_load2);
xlabel('Time (ms)');
if handles.EEG_indicator == 1
    ylabel('Potential (uV)');
else
    ylabel('Magnetic field (fT)');
end

if ~isempty(handles.ch_config)
    if handles.EEG_indicator == 1
        axes(handles.topoplot1);
        topoplot(handles.avg_load1(:,round(handles.pre)),handles.ch_config);
        axes(handles.topoplot2);
        topoplot(handles.avg_load2(:,round(handles.pre)),handles.ch_config);
    else
        topo_plot(hObject, eventdata, handles,handles.topoplot1,0,handles.avg_load1,[],[],handles.ch_config,[]);
        topo_plot(hObject, eventdata, handles,handles.topoplot2,0,handles.avg_load2,[],[],handles.ch_config,[]);
    end
end

set(handles.back_step1_load1,'Visible','on');
set(handles.back_step2_load1,'Visible','on');
set(handles.back_step3_load1,'Visible','on');
set(handles.back_step1_load2,'Visible','on');
set(handles.back_step2_load2,'Visible','on');
set(handles.back_step3_load2,'Visible','on');

set(handles.forward_step1_load1,'Visible','on');
set(handles.forward_step2_load1,'Visible','on');
set(handles.forward_step3_load1,'Visible','on');
set(handles.forward_step1_load2,'Visible','on');
set(handles.forward_step2_load2,'Visible','on');
set(handles.forward_step3_load2,'Visible','on');

set(handles.current_time_load1,'Visible','on');
set(handles.current_time_load2,'Visible','on');

set(handles.axes1,'Visible','on');
set(handles.axes2,'Visible','on');

if get(handles.projection_test,'Value') == 1
    avg2_text_string = ['average response of condition ' num2str(load2_filename_value)];
    set(handles.avg2_text,'String',avg2_text_string);
end

%%%%internal waveform ploting function
function waveform_plot(hObject, eventdata, handles,plot_location,plot_time,data_avg,data_RMS)
axes(plot_location);
t = [-handles.pre*1000/handles.sf:1000/handles.sf:(handles.post)*1000/handles.sf];
plot(t,data_avg,'k');
%axis([min(t) max(t) -inf inf])
axis([-handles.pre*1000/handles.sf handles.post*1000/handles.sf 9/8*min(min(data_avg)) 9/8*max(max(data_avg))])
hold on;
plot(t,data_RMS,'r','linewidth',3);
Y = get(plot_location,'Ylim');
line([plot_time plot_time],[Y(1) Y(2)]);
hold off;

%%%%internal topo plot function
function topo_plot(hObject, eventdata, handles,plot_location,plot_time,data,topocolormap,phasorscale,channel_config,topomask)
axes(plot_location);
megtopoplot(data(:,round(handles.pre+plot_time*handles.sf/1000)),topocolormap,phasorscale,channel_config,topomask);

% --- Executes on button press in half_half_indicator.
function half_half_indicator_Callback(hObject, eventdata, handles)
% hObject    handle to half_half_indicator (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of half_half_indicator

set(handles.iteration_number,'Visible','off');

guidata(hObject, handles);

% --- Executes on button press in interleaved_indicator.
function interleaved_indicator_Callback(hObject, eventdata, handles)
% hObject    handle to interleaved_indicator (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of interleaved_indicator

set(handles.iteration_number,'Visible','off');

guidata(hObject, handles);



function template_dir_Callback(hObject, eventdata, handles)
% hObject    handle to template_dir (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of template_dir as text
%        str2double(get(hObject,'String')) returns contents of template_dir as a double
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function template_dir_CreateFcn(hObject, eventdata, handles)
% hObject    handle to template_dir (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function experimental_dir_Callback(hObject, eventdata, handles)
% hObject    handle to experimental_dir (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of experimental_dir as text
%        str2double(get(hObject,'String')) returns contents of experimental_dir as a double
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function experimental_dir_CreateFcn(hObject, eventdata, handles)
% hObject    handle to experimental_dir (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in baseline_correction_1.
function baseline_correction_1_Callback(hObject, eventdata, handles)
% hObject    handle to baseline_correction_1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of baseline_correction_1

if strcmp(get(handles.axes1,'Visible'),'on')
    if get(handles.baseline_correction_1,'Value') == 1
        handles.avg_load1 = baseline_correction(hObject, eventdata, handles, handles.avg_load1);
        handles.RMS_avg_load1 = sqrt(mean(handles.avg_load1.^2,1));
    end
    
    waveform_plot(hObject, eventdata, handles,handles.axes1,handles.plot_time1,handles.avg_load1,handles.RMS_avg_load1);
    
    if ~isempty(handles.ch_config)
        if handles.EEG_indicator == 1
            axes(handles.topoplot1);
            topoplot(handles.avg_load1(:,round(handles.pre+handles.plot_time1)),handles.ch_config);
        else
            topo_plot(hObject, eventdata, handles,handles.topoplot1,handles.plot_time1,handles.avg_load1,[],[],handles.ch_config,[]);
        end
    end
    
end
%guidata(hObject, handles);


%%%%internal function for baseline correction
function [data_baseline_corrected] = baseline_correction(hObject, eventdata, handles, data)

data_baseline_corrected = data - mean(data(:,[1:handles.pre]),2)*ones(1,size(data,2));




% --- Executes on button press in random_indicator.
function random_indicator_Callback(hObject, eventdata, handles)
% hObject    handle to random_indicator (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of random_indicator

set(handles.iteration_number,'Visible','on');

guidata(hObject, handles);



function iteration_number_Callback(hObject, eventdata, handles)
% hObject    handle to iteration_number (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of iteration_number as text
%        str2double(get(hObject,'String')) returns contents of iteration_number as a double
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function iteration_number_CreateFcn(hObject, eventdata, handles)
% hObject    handle to iteration_number (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function sampling_frequency_Callback(hObject, eventdata, handles)
% hObject    handle to sampling_frequency (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of sampling_frequency as text
%        str2double(get(hObject,'String')) returns contents of sampling_frequency as a double

handles.sf = str2num(get(handles.sampling_frequency,'String'));

guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function sampling_frequency_CreateFcn(hObject, eventdata, handles)
% hObject    handle to sampling_frequency (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function channel_selection_Callback(hObject, eventdata, handles)
% hObject    handle to channel_selection (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of channel_selection as text
%        str2double(get(hObject,'String')) returns contents of channel_selection as a double

handles.channel_selection_string = get(handles.channel_selection,'String');
handles.channel_selection_value = get(handles.channel_selection,'Value');

if strcmp(get(handles.axes1,'Visible'),'on')
    if handles.channel_selection_value == 1 || handles.channel_selection_value == 2
        handles.channel_selection_num = [];
        handles.avg_load1 = handles.avg_load1_orig;
        handles.avg_load2 = handles.avg_load2_orig;
    else
        [filename, pathname] = uigetfile('*.txt', 'File to load');
        handles.channel_selection_num = dlmread([pathname filename]);
        %%%%set the unselected channel to zeros
        handles.avg_load1 = zeros(size(handles.avg_load1_orig,1),size(handles.avg_load1_orig,2));
        handles.avg_load2 = zeros(size(handles.avg_load2_orig,1),size(handles.avg_load2_orig,2));
        handles.avg_load1(handles.channel_selection_num,:) = handles.avg_load1_orig(handles.channel_selection_num,:);
        handles.avg_load2(handles.channel_selection_num,:) = handles.avg_load2_orig(handles.channel_selection_num,:);
    end
    
    handles.RMS_avg_load1 = sqrt(mean(handles.avg_load1.^2,1));
    handles.RMS_avg_load2 = sqrt(mean(handles.avg_load2.^2,1));
    
    
    waveform_plot(hObject, eventdata, handles,handles.axes1,handles.plot_time1,handles.avg_load1,handles.RMS_avg_load1);
    waveform_plot(hObject, eventdata, handles,handles.axes2,handles.plot_time2,handles.avg_load2,handles.RMS_avg_load2);
    
    if ~isempty(handles.ch_config)
        if handles.EEG_indicator == 1
            axes(handles.topoplot1);
            topoplot(handles.avg_load1(:,round(handles.pre+handles.plot_time1)),handles.ch_config);
            axes(handles.topoplot2);
            topoplot(handles.avg_load2(:,round(handles.pre+handles.plot_time2)),handles.ch_config);
        else
            topo_plot(hObject, eventdata, handles,handles.topoplot1,handles.plot_time1,handles.avg_load1,[],[],handles.ch_config,[]);
            topo_plot(hObject, eventdata, handles,handles.topoplot2,handles.plot_time2,handles.avg_load2,[],[],handles.ch_config,[]);
        end
    end
    
else
    if handles.channel_selection_value == 1 || handles.channel_selection_value == 2
        handles.channel_selection_num = [];
    else
        [filename, pathname] = uigetfile('*.txt', 'File to load');
        handles.channel_selection_num = dlmread([pathname filename]);
    end
end

set(handles.channel_selection,'Value',handles.channel_selection_value);

guidata(hObject, handles);




% --- Executes during object creation, after setting all properties.
function channel_selection_CreateFcn(hObject, eventdata, handles)
% hObject    handle to channel_selection (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



% --- Executes on selection change in load1_filename_list.
function load1_filename_list_Callback(hObject, eventdata, handles)
% hObject    handle to load1_filename_list (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns load1_filename_list contents as cell array
%        contents{get(hObject,'Value')} returns selected item from load1_filename_list
if strcmp(get(handles.axes1,'Visible'),'on')
    gen_avg_plot_Callback(hObject, eventdata, handles)
end


% --- Executes during object creation, after setting all properties.
function load1_filename_list_CreateFcn(hObject, eventdata, handles)
% hObject    handle to load1_filename_list (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in load2_filename_list.
function load2_filename_list_Callback(hObject, eventdata, handles)
% hObject    handle to load2_filename_list (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns load2_filename_list contents as cell array
%        contents{get(hObject,'Value')} returns selected item from load2_filename_list
if strcmp(get(handles.axes2,'Visible'),'on')
    gen_avg_plot_Callback(hObject, eventdata, handles)
end


% --- Executes during object creation, after setting all properties.
function load2_filename_list_CreateFcn(hObject, eventdata, handles)
% hObject    handle to load2_filename_list (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in load1.
function load1_Callback(hObject, eventdata, handles)
% hObject    handle to load1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns load1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from load1

handles.load1_value = get(handles.load1,'Value');
%handles.load1_string = get(handles.load1,'String');

if handles.load1_value == 2 %%%%load .mat file
    
    set(handles.load_button,'visible','on');
    
    [filename, pathname] = uigetfile('*.mat', 'Load data file');
    handles.pathname = pathname;
    handles.filename = filename;
    handles.filenamelist1{end+1}=filename;  % name of all files
    handles.pathnamelist1{end+1}=pathname;  % path of all files
    
    handles.rec1{length(handles.filenamelist1)}={};
    
    guidata(hObject,handles);
    
    %%%%update GUI
    set(handles.load1_filename_list,'String',handles.filenamelist1);
    set(handles.load1_filename_list,'Value', length(handles.filenamelist1));
    set(handles.load1,'Value',1)
    
elseif handles.load1_value == 3 %%%%load from EEGLAB current set
    
    handles.EEG_indicator = 1;
    
    global EEG;
    eval(['handles.load1_data_all.file',num2str(size(get(handles.load1_filename_list,'String'),1)+1),' = EEG.data;'])
    handles.ch_config = EEG.chanlocs;
    handles.sf = EEG.srate;
    handles.pre = round(abs(EEG.xmin)*handles.sf);
    handles.post = round(EEG.xmax*handles.sf);
    
    handles.filenamelist1{end+1} = EEG.filename;
    
    set(handles.sampling_frequency,'String',num2str(handles.sf));
    set(handles.pre_trigger_time,'String',num2str(handles.pre));
    set(handles.post_trigger_time,'String',num2str(handles.post));
    
    set(handles.load_button,'visible','off');
    
    set(handles.load1_filename_list,'String',handles.filenamelist1);
    set(handles.load1_filename_list,'Value', length(handles.filenamelist1));
    set(handles.load1,'Value',1)
    
    guidata(hObject,handles);
end

if handles.EEG_indicator == 1
    %%%%initiating appearence
    if ~isempty(handles.filenamelist1)
        set(handles.latency1_text,'Visible','on');
        set(handles.latency1,'Visible','on');
    end
end


% --- Executes during object creation, after setting all properties.
function load1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to load1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in load2.
function load2_Callback(hObject, eventdata, handles)
% hObject    handle to load2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns load2 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from load2

handles.load2_value = get(handles.load2,'Value');
%handles.load2_string = get(handles.load2,'String');

if handles.load2_value == 2 %%%%load .mat file
    
    [filename, pathname] = uigetfile('*.mat', 'File to load');
    handles.pathname = pathname;
    handles.filename = filename;
    handles.filenamelist2{end+1}=filename;  % name of all files
    handles.pathnamelist2{end+1}=pathname;  % path of all files
    
    handles.rec2{length(handles.filenamelist2)}={};
    
    guidata(hObject,handles);
    
    %%%%update GUI
    set(handles.load2_filename_list,'String',handles.filenamelist2);
    set(handles.load2_filename_list,'Value', length(handles.filenamelist2));
    set(handles.load2,'Value',1)
    
elseif handles.load2_value == 3 %%%%load from EEGLAB current set
    handles.EEG_indicator = 1;
    global EEG;
    eval(['handles.load2_data_all.file',num2str(length(get(handles.load2_filename_list,'String'))+1),' = EEG.data;'])
    handles.ch_config = EEG.chanlocs;
    handles.sf = EEG.srate;
    handles.pre = round(abs(EEG.xmin)*handles.sf);
    handles.post = round(EEG.xmax*handles.sf);
    
    handles.filenamelist2{end+1} = EEG.filename;
    
    set(handles.sampling_frequency,'String',num2str(handles.sf));
    set(handles.pre_trigger_time,'String',num2str(handles.pre));
    set(handles.post_trigger_time,'String',num2str(handles.post));
    
    set(handles.load_button,'visible','off');
    
    set(handles.load2_filename_list,'String',handles.filenamelist2);
    set(handles.load2_filename_list,'Value', length(handles.filenamelist2));
    set(handles.load2,'Value',1)
    guidata(hObject,handles);
end

if handles.EEG_indicator == 1
    %%%%initiating appearence
    if handles.angle_test_value == 1
        if ~isempty(handles.filenamelist2)
            set(handles.latency2_text,'Visible','on');
            set(handles.latency2,'Visible','on');
            
            set(handles.half_window_width_text,'Visible','on');
            set(handles.half_window_width,'Visible','on');
            
            set(handles.null_gen_panel,'Visible','on');
            
            set(handles.gen_button,'Visible','on');
            set(handles.save_button,'Visible','on');
            
        end
    elseif handles.projection_test_value == 1
        if length(handles.filenamelist2) <=6
            visible_length = length(handles.filenamelist2);
            set(handles.gen_button,'Visible','on');
            set(handles.save_button,'Visible','on');
        else
            visible_length = 6;
            set(handles.gen_button,'Visible','on');
            set(handles.save_button,'Visible','on');
        end
        
        for i = 1:visible_length
            eval(['handles_text_open = handles.latency',num2str(i+1),'_text;'])
            eval(['handles_latency_open = handles.latency',num2str(i+1),';'])
            
            set(handles_text_open,'Visible','on');
            set(handles_latency_open,'Visible','on');
        end
    elseif handles.angle_dynamics_value == 1;
        if ~isempty(handles.filenamelist2)
            set(handles.latency2_text,'Visible','on');
            set(handles.latency2,'Visible','on');
            set(handles.null_gen_panel,'Visible','on');
            set(handles.gen_button,'Visible','on');
            set(handles.save_button,'Visible','on');
        end
    end
end

% --- Executes during object creation, after setting all properties.
function load2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to load2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in angle_test.
function angle_test_Callback(hObject, eventdata, handles)
% hObject    handle to angle_test (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of angle_test

setguiasopening(hObject)



% %%%%internal function for ploting
% function ploting_Callback(hObject, eventdata, handles)
% % hObject    handle to gen_avg_plot (see GCBO)
% % eventdata  reserved - to be defined in a future version of MATLAB
% % handles    structure with handles and user data (see GUIDATA)
%
% %%%%loading data
% template_data = cell2mat(struct2cell(load(get(handles.template_dir,'String'))));
%
% %%%%channel selection
% channel_selection_file = get(handles.channel_selection,'String');
% if strcmp('default',channel_selection_file)
%     template_data = template_data;
% else
%     channel_selection = dlmread(channel_selection_file)+1;
%     template_data = template_data(channel_selection,:);
% end
%
% %%%%obtaining average template file
% sampling_frequency = str2num(get(handles.sampling_frequency,'String'));
% pre_trigger = str2num(get(handles.pre_trigger_time,'String'))*sampling_frequency/1000;
% post_trigger = str2num(get(handles.post_trigger_time,'String'))*sampling_frequency/1000;
% % reshaped_template_data = reshape(template_data,[size(template_data,1),(pre_trigger+post_trigger),size(template_data,2)/(pre_trigger+post_trigger)]);
% % avg_template = mean(reshaped_template_data,3);
% avg_template = mean(template_data,3);
% %%%%baseline correction
% if get(handles.baseline_correction_1,'Value') == 1
%     avg_template = avg_template - mean(avg_template(:,[1:pre_trigger]),2)*ones(1,size(avg_template,2));
% end
%
% axes(handles.axes1);
% t = [-pre_trigger*1000/sampling_frequency:1000/sampling_frequency:(post_trigger-1)*1000/sampling_frequency];
% plot(t,avg_template,'k');
% axis([min(t) max(t) -inf inf])
% hold on;
% RMS_avg_template = sqrt(mean(avg_template.^2,1));
% plot(t,RMS_avg_template,'r','linewidth',3);
% axis([min(t) max(t) -inf inf])
% hold off;
%
% guidata(hObject, handles);


% --- Executes on button press in remove1.
function remove1_Callback(hObject, eventdata, handles)
% hObject    handle to remove1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
ss=get(handles.load1_filename_list,'Value');

handles.rec1(ss:end-1)=handles.rec1(ss+1:end);
handles.rec1=handles.rec1(1:end-1);
handles.filenamelist1(ss:end-1)=handles.filenamelist1(ss+1:end);
handles.filenamelist1=handles.filenamelist1(1:end-1);
handles.pathnamelist1(ss:end-1)=handles.pathnamelist1(ss+1:end);
handles.pathnamelist1=handles.pathnamelist1(1:end-1);
if length(handles.filenamelist1)<ss && ss~=1
    ss=ss-1;
end
set(handles.load1_filename_list,'Value',ss);
set(handles.load1_filename_list,'String',handles.filenamelist1);
guidata(hObject,handles);
if length(handles.filenamelist1) == 0
    reset1_Callback(hObject, eventdata, handles);
end

% --- Executes on button press in remove2.
function remove2_Callback(hObject, eventdata, handles)
% hObject    handle to remove2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

ss=get(handles.load2_filename_list,'Value');

handles.rec2(ss:end-1)=handles.rec2(ss+1:end);
handles.rec2=handles.rec2(1:end-1);
handles.filenamelist2(ss:end-1)=handles.filenamelist2(ss+1:end);
handles.filenamelist2=handles.filenamelist2(1:end-1);
handles.pathnamelist2(ss:end-1)=handles.pathnamelist2(ss+1:end);
handles.pathnamelist2=handles.pathnamelist2(1:end-1);
if length(handles.filenamelist2)<ss && ss~=1
    ss=ss-1;
end
set(handles.load2_filename_list,'Value',ss);
set(handles.load2_filename_list,'String',handles.filenamelist2);
guidata(hObject,handles);
if length(handles.filenamelist2) == 0
    reset2_Callback(hObject, eventdata, handles);
end


% --- Executes on button press in baseline_correction_2.
function baseline_correction_2_Callback(hObject, eventdata, handles)
% hObject    handle to baseline_correction_2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of baseline_correction_2

if strcmp(get(handles.axes1,'Visible'),'on')
    if get(handles.baseline_correction_2,'Value') == 1
        handles.avg_load2 = baseline_correction(hObject, eventdata, handles, handles.avg_load2);
        handles.RMS_avg_load2 = sqrt(mean(handles.avg_load2.^2,1));
    end
    
    waveform_plot(hObject, eventdata, handles,handles.axes2,handles.plot_time2,handles.avg_load2,handles.RMS_avg_load2);
    
    if ~isempty(handles.ch_config)
        if handles.EEG_indicator == 1
            axes(handles.topoplot2);
            topoplot(handles.avg_load2(:,round(handles.pre+handles.plot_time2)),handles.ch_config);
        else
            topo_plot(hObject, eventdata, handles,handles.topoplot2,handles.plot_time2,handles.avg_load2,[],[],handles.ch_config,[]);
        end
    end
    
    
end

%guidata(hObject, handles);



function current_time_load1_Callback(hObject, eventdata, handles)
% hObject    handle to current_time_load1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of current_time_load1 as text
%        str2double(get(hObject,'String')) returns contents of current_time_load1 as a double

handles.angle_test_value = get(handles.angle_test,'Value');
handles.projection_test_value = get(handles.projection_test,'Value');
handles.angle_dynamics_value = get(handles.angle_dynamics,'Value');

handles.plot_time1 = str2num(get(handles.current_time_load1,'String'));
if handles.plot_time1 > handles.post*1000/handles.sf || handles.plot_time1 < -handles.pre*1000/handles.sf
    fprintf('out of range')
else
    handles.latency_time1 = handles.plot_time1;
    set(handles.latency1,'String',num2str(handles.latency_time1));
    
    guidata(hObject, handles);
    
    %%baseline correction
    if get(handles.baseline_correction_1,'Value') == 1
        handles.avg_load1 = baseline_correction(hObject, eventdata, handles, handles.avg_load1);
        handles.RMS_avg_load1 = sqrt(mean(handles.avg_load1.^2,1));
    end
    
    waveform_plot(hObject, eventdata, handles,handles.axes1,handles.plot_time1,handles.avg_load1,handles.RMS_avg_load1);
    
    if ~isempty(handles.ch_config)
        if handles.EEG_indicator == 1
            axes(handles.topoplot1);
            topoplot(handles.avg_load1(:,handles.pre+round(handles.plot_time1*handles.sf/1000)),handles.ch_config);
        else
            topo_plot(hObject, eventdata, handles,handles.topoplot1,handles.plot_time1,handles.avg_load1,[],[],handles.ch_config,[]);
        end
    end
end


% --- Executes during object creation, after setting all properties.
function current_time_load1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to current_time_load1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function current_time_load2_Callback(hObject, eventdata, handles)
% hObject    handle to current_time_load2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of current_time_load2 as text
%        str2double(get(hObject,'String')) returns contents of current_time_load2 as a double

handles.angle_test_value = get(handles.angle_test,'Value');
handles.projection_test_value = get(handles.projection_test,'Value');
handles.angle_dynamics_value = get(handles.angle_dynamics,'Value');

handles.plot_time2 = str2num(get(handles.current_time_load2,'String'));

if handles.plot_time2 > handles.post*1000/handles.sf || handles.plot_time2 < -handles.pre*1000/handles.sf
    fprintf('out of range')
else
    %%%%updating time selection
    if handles.projection_test_value ~=1
        handles.latency_time2 = handles.plot_time2;
        set(handles.latency2,'String',num2str(handles.latency_time2));
    else
        load1_filename_list = get(handles.load1_filename_list,'String');
        load2_filename_list = get(handles.load2_filename_list,'String');
        load1_filename_value = get(handles.load1_filename_list,'value');
        load2_filename_value = get(handles.load2_filename_list,'value');
        
        handles.latency_time2 = handles.plot_time2;
        
        for i = load2_filename_value
            eval(['update_handle = handles.latency',num2str(i+1),';'])
            set(update_handle,'String',num2str(handles.latency_time2));
        end
    end
    
    guidata(hObject, handles);
    
    %%%%updating plot2
    %%baseline correction
    if get(handles.baseline_correction_2,'Value') == 1
        handles.avg_load2 = baseline_correction(hObject, eventdata, handles, handles.avg_load2);
        handles.RMS_avg_load2 = sqrt(mean(handles.avg_load2.^2,1));
    end
    
    waveform_plot(hObject, eventdata, handles,handles.axes2,handles.plot_time2,handles.avg_load2,handles.RMS_avg_load2);
    
    if ~isempty(handles.ch_config)
        if handles.EEG_indicator == 1
            axes(handles.topoplot2);
            topoplot(handles.avg_load1(:,handles.pre+round(handles.plot_time2*handles.sf/1000)),handles.ch_config);
        else
            topo_plot(hObject, eventdata, handles,handles.topoplot2,handles.plot_time2,handles.avg_load2,[],[],handles.ch_config,[]);
        end
    end
end


% --- Executes during object creation, after setting all properties.
function current_time_load2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to current_time_load2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in back_step1_load1.
function back_step1_load1_Callback(hObject, eventdata, handles)
% hObject    handle to back_step1_load1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

handles.plot_time1 = str2num(get(handles.current_time_load1,'String'));
handles.plot_time1 = handles.plot_time1 - 1000/handles.sf;
if handles.plot_time1 <= -handles.pre*1000/handles.sf
    fprintf('out of range')
else
    set(handles.current_time_load1,'String',handles.plot_time1);
    
    current_time_load1_Callback(hObject, eventdata, handles)
    
    guidata(hObject, handles);
end




% --- Executes on button press in forward_step1_load1.
function forward_step1_load1_Callback(hObject, eventdata, handles)
% hObject    handle to forward_step1_load1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

handles.plot_time1 = str2num(get(handles.current_time_load1,'String'));
handles.plot_time1 = handles.plot_time1 + 1000/handles.sf;
if handles.plot_time1 > handles.post*1000/handles.sf
    fprintf('out of range')
else
    set(handles.current_time_load1,'String',handles.plot_time1);
    
    current_time_load1_Callback(hObject, eventdata, handles)
    
    guidata(hObject, handles);
end


% --- Executes on button press in back_step2_load1.
function back_step2_load1_Callback(hObject, eventdata, handles)
% hObject    handle to back_step2_load1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

handles.plot_time1 = str2num(get(handles.current_time_load1,'String'));
handles.plot_time1 = handles.plot_time1 - 10*1000/handles.sf;
if handles.plot_time1 <= -handles.pre*1000/handles.sf
    fprintf('out of range')
else
    set(handles.current_time_load1,'String',handles.plot_time1);
    
    current_time_load1_Callback(hObject, eventdata, handles)
    
    guidata(hObject, handles);
end


% --- Executes on button press in back_step3_load1.
function back_step3_load1_Callback(hObject, eventdata, handles)
% hObject    handle to back_step3_load1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

handles.plot_time1 = str2num(get(handles.current_time_load1,'String'));
handles.plot_time1 = handles.plot_time1 - 100*1000/handles.sf;
if handles.plot_time1 <= -handles.pre*1000/handles.sf
    fprintf('out of range')
else
    set(handles.current_time_load1,'String',handles.plot_time1);
    
    current_time_load1_Callback(hObject, eventdata, handles)
    
    guidata(hObject, handles);
end


% --- Executes on button press in forward_step2_load1.
function forward_step2_load1_Callback(hObject, eventdata, handles)
% hObject    handle to forward_step2_load1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

handles.plot_time1 = str2num(get(handles.current_time_load1,'String'));
handles.plot_time1 = handles.plot_time1 + 10*1000/handles.sf;
if handles.plot_time1 > handles.post*1000/handles.sf
    fprintf('out of range')
else
    set(handles.current_time_load1,'String',handles.plot_time1);
    
    current_time_load1_Callback(hObject, eventdata, handles)
    
    guidata(hObject, handles);
end


% --- Executes on button press in forward_step3_load1.
function forward_step3_load1_Callback(hObject, eventdata, handles)
% hObject    handle to forward_step3_load1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

handles.plot_time1 = str2num(get(handles.current_time_load1,'String'));
handles.plot_time1 = handles.plot_time1 + 100*1000/handles.sf;
if handles.plot_time1 > handles.post*1000/handles.sf
    fprintf('out of range')
else
    set(handles.current_time_load1,'String',handles.plot_time1);
    
    current_time_load1_Callback(hObject, eventdata, handles)
    
    guidata(hObject, handles);
end


% --- Executes on button press in back_step1_load2.
function back_step1_load2_Callback(hObject, eventdata, handles)
% hObject    handle to back_step1_load2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

handles.plot_time2 = str2num(get(handles.current_time_load2,'String'));
handles.plot_time2 = handles.plot_time2 - 1000/handles.sf;
if handles.plot_time2 <= -handles.pre*1000/handles.sf
    fprintf('out of range')
else
    set(handles.current_time_load2,'String',handles.plot_time2);
    
    current_time_load2_Callback(hObject, eventdata, handles)
    
    guidata(hObject, handles);
end


% --- Executes on button press in forward_step1_load2.
function forward_step1_load2_Callback(hObject, eventdata, handles)
% hObject    handle to forward_step1_load2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

handles.plot_time2 = str2num(get(handles.current_time_load2,'String'));
handles.plot_time2 = handles.plot_time2 + 1000/handles.sf;
if handles.plot_time2 > handles.post*1000/handles.sf
    fprintf('out of range')
else
    set(handles.current_time_load2,'String',handles.plot_time2);
    
    current_time_load2_Callback(hObject, eventdata, handles)
    
    guidata(hObject, handles);
end


% --- Executes on button press in back_step2_load2.
function back_step2_load2_Callback(hObject, eventdata, handles)
% hObject    handle to back_step2_load2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

handles.plot_time2 = str2num(get(handles.current_time_load2,'String'));
handles.plot_time2 = handles.plot_time2 - 10*1000/handles.sf;
if handles.plot_time2 <= -handles.pre*1000/handles.sf
    fprintf('out of range')
else
    set(handles.current_time_load2,'String',handles.plot_time2);
    
    current_time_load2_Callback(hObject, eventdata, handles)
    
    guidata(hObject, handles);
end

% --- Executes on button press in back_step3_load2.
function back_step3_load2_Callback(hObject, eventdata, handles)
% hObject    handle to back_step3_load2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

handles.plot_time2 = str2num(get(handles.current_time_load2,'String'));
handles.plot_time2 = handles.plot_time2 - 100*1000/handles.sf;
if handles.plot_time2 <= -handles.pre*1000/handles.sf
    fprintf('out of range')
else
    set(handles.current_time_load2,'String',handles.plot_time2);
    
    current_time_load2_Callback(hObject, eventdata, handles)
    
    guidata(hObject, handles);
end


% --- Executes on button press in forward_step2_load2.
function forward_step2_load2_Callback(hObject, eventdata, handles)
% hObject    handle to forward_step2_load2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

handles.plot_time2 = str2num(get(handles.current_time_load2,'String'));
handles.plot_time2 = handles.plot_time2 + 10*1000/handles.sf;
if handles.plot_time2 > handles.post*1000/handles.sf
    fprintf('out of range')
else
    set(handles.current_time_load2,'String',handles.plot_time2);
    
    current_time_load2_Callback(hObject, eventdata, handles)
    
    guidata(hObject, handles);
end


% --- Executes on button press in forward_step3_load2.
function forward_step3_load2_Callback(hObject, eventdata, handles)
% hObject    handle to forward_step3_load2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

handles.plot_time2 = str2num(get(handles.current_time_load2,'String'));
handles.plot_time2 = handles.plot_time2 + 100*1000/handles.sf;
if handles.plot_time2 > handles.post*1000/handles.sf
    fprintf('out of range')
else
    set(handles.current_time_load2,'String',handles.plot_time2);
    
    current_time_load2_Callback(hObject, eventdata, handles)
    
    guidata(hObject, handles);
end


% --- Executes on button press in save_button.
function save_button_Callback(hObject, eventdata, handles)
% hObject    handle to save_button (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

handles.angle_test_value = get(handles.angle_test,'Value');
handles.projection_test_value = get(handles.projection_test,'Value');
handles.angle_dynamics_value = get(handles.angle_dynamics,'Value');

if handles.angle_test_value == 1
    [fname, pname] = uiputfile('*.mat', 'Save individual angle test results as ');
    if fname(1)~=0 && pname(1)~=0
        angle_simliarity_results.sampling_frequency = handles.sf;
        angle_simliarity_results.pre_trigger = handles.pre;
        angle_simliarity_results.post_trigger = handles.post;
        angle_simliarity_results.half_window_width = handles.half_window_width_value;
        angle_simliarity_results.exp_latecy = handles.exp_latency;
        angle_simliarity_results.within_cos_angle = handles.within_cos_angle;
        angle_simliarity_results.between_cos_angle = handles.between_cos_angle;
        save([pname,fname],'angle_simliarity_results');
    end
elseif handles.projection_test_value == 1
    [fname, pname] = uiputfile('*.mat', 'Save individual projection test results as ');
    if fname(1)~=0 && pname(1)~=0
        dynamic_projection_results.sampling_frequency = handles.sf;
        dynamic_projection_results.pre_trigger = handles.pre;
        dynamic_projection_results.post_trigger = handles.post;
        dynamic_projection_results.template_latency = handles.template_latency;
        dynamic_projection_results.exp_latency = handles.exp_latency;
        dynamic_projection_results.projection = handles.projection_exp;
        save([pname,fname],'dynamic_projection_results')
    end
elseif handles.angle_dynamics_value == 1
    [fname, pname] = uiputfile('*.mat', 'Save individual angle dynamics results as ');
    if fname(1)~=0 && pname(1)~=0
        angle_dynamics_results.sampling_frequency = handles.sf;
        angle_dynamics_results.pre_trigger = handles.pre;
        angle_dynamics_results.post_trigger = handles.post;
        angle_dynamics_results.template_latency = handles.template_latency;
        angle_dynamics_results.exp_latency = handles.exp_latency;
        %angle_dynamics_results.within_cos_angle = handles.within_cos_angle;
        angle_dynamics_results.within_cos_angle1 = handles.within_cos_angle1;
        angle_dynamics_results.within_cos_angle2 = handles.within_cos_angle2;
        angle_dynamics_results.between_cos_angle = handles.between_cos_angle;
        save([pname,fname],'angle_dynamics_results');
    end
end


function latency3_Callback(hObject, eventdata, handles)
% hObject    handle to latency3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of latency3 as text
%        str2double(get(hObject,'String')) returns contents of latency3 as a double


% --- Executes during object creation, after setting all properties.
function latency3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to latency3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function latency4_Callback(hObject, eventdata, handles)
% hObject    handle to latency4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of latency4 as text
%        str2double(get(hObject,'String')) returns contents of latency4 as a double


% --- Executes during object creation, after setting all properties.
function latency4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to latency4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function latency5_Callback(hObject, eventdata, handles)
% hObject    handle to latency5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of latency5 as text
%        str2double(get(hObject,'String')) returns contents of latency5 as a double


% --- Executes during object creation, after setting all properties.
function latency5_CreateFcn(hObject, eventdata, handles)
% hObject    handle to latency5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function latency6_Callback(hObject, eventdata, handles)
% hObject    handle to latency6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of latency6 as text
%        str2double(get(hObject,'String')) returns contents of latency6 as a double


% --- Executes during object creation, after setting all properties.
function latency6_CreateFcn(hObject, eventdata, handles)
% hObject    handle to latency6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function latency7_Callback(hObject, eventdata, handles)
% hObject    handle to latency7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of latency7 as text
%        str2double(get(hObject,'String')) returns contents of latency7 as a double


% --- Executes during object creation, after setting all properties.
function latency7_CreateFcn(hObject, eventdata, handles)
% hObject    handle to latency7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in load_button.
function load_button_Callback(hObject, eventdata, handles)
% hObject    handle to load_button (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

handles.load1_data_all = [];
handles.load2_data_all = [];

handles.sf = str2num(get(handles.sampling_frequency,'String'));
handles.pre = str2num(get(handles.pre_trigger_time,'String'))*handles.sf/1000;
handles.post = str2num(get(handles.post_trigger_time,'String'))*handles.sf/1000;

load1_filename_list = get(handles.load1_filename_list,'String');
load2_filename_list = get(handles.load2_filename_list,'String');

%%%%loading data
for i = 1:length(load1_filename_list)
    eval(['handles.load1_data_all.file',num2str(i),' = cell2mat(struct2cell(load([handles.pathnamelist1{i} handles.filenamelist1{i}])));'])
end
for i = 1:length(load2_filename_list)
    eval(['handles.load2_data_all.file',num2str(i),' = cell2mat(struct2cell(load([handles.pathnamelist2{i} handles.filenamelist2{i}])));'])
end

%%%%initiating appearence
if ~isempty(handles.filenamelist1)
    set(handles.latency1_text,'Visible','on');
    set(handles.latency1,'Visible','on');
end

if handles.angle_test_value == 1
    if ~isempty(handles.filenamelist2)
        set(handles.latency2_text,'Visible','on');
        set(handles.latency2,'Visible','on');
        
        set(handles.half_window_width_text,'Visible','on');
        set(handles.half_window_width,'Visible','on');
        
        set(handles.null_gen_panel,'Visible','on');
        
        set(handles.gen_button,'Visible','on');
        set(handles.save_button,'Visible','on');
        
    end
elseif handles.projection_test_value == 1
    if length(handles.filenamelist2) <=6
        visible_length = length(load2_filename_list);
        set(handles.gen_button,'Visible','on');
        set(handles.save_button,'Visible','on');
    else
        visible_length = 6;
        set(handles.gen_button,'Visible','on');
        set(handles.save_button,'Visible','on');
    end
    
    for i = 1:visible_length
        eval(['handles_text_open = handles.latency',num2str(i+1),'_text;'])
        eval(['handles_latency_open = handles.latency',num2str(i+1),';'])
        
        set(handles_text_open,'Visible','on');
        set(handles_latency_open,'Visible','on');
    end
elseif handles.angle_dynamics_value == 1;
    if ~isempty(handles.filenamelist2)
        set(handles.latency2_text,'Visible','on');
        set(handles.latency2,'Visible','on');
        set(handles.null_gen_panel,'Visible','on');
        set(handles.gen_button,'Visible','on');
        set(handles.save_button,'Visible','on');
    end
end


guidata(hObject, handles);


% --- Executes on button press in reset1.
function reset1_Callback(hObject, eventdata, handles)
% hObject    handle to reset1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles.load1_data_all = [];

handles.pathnamelist1 = {};
handles.filenamelist1 = {};
handles.rec1 = {};

set(handles.load1_filename_list,'String',handles.filenamelist1);
set(handles.load1_filename_list,'Value', length(handles.filenamelist1));
set(handles.load1,'Value',1)

guidata(hObject, handles);


%%%%initiating values
%%%%initiating to-be-recorded variables
handles.within_cos_angle = [];
handles.betwen_cos_angle = [];
handles.template_latency = [];
handles.exp_latency = [];
handles.projection_exp = [];
handles.EEG_indicator = [];


%%%%initiate values
set(handles.load1_filename_list,'Value',0);
set(handles.current_time_load1,'String','0');
set(handles.latency1,'String','0');
set(handles.half_half_indicator,'Value',1);
set(handles.interleaved_indicator,'Value',0);
set(handles.random_indicator,'Value',0);


%%%%function selection
handles.angle_test_value = get(handles.angle_test,'Value');
handles.projection_test_value = get(handles.projection_test,'Value');
handles.angle_dynamics_value = get(handles.angle_dynamics,'Value');

%%%%initiating display
%%%%general for all 3 functions
set(handles.back_step1_load1,'Visible','off');
set(handles.back_step2_load1,'Visible','off');
set(handles.back_step3_load1,'Visible','off');

set(handles.forward_step1_load1,'Visible','off');
set(handles.forward_step2_load1,'Visible','off');
set(handles.forward_step3_load1,'Visible','off');

set(handles.current_time_load1,'Visible','off');

set(handles.axes1,'Visible','off');
set(handles.axes3,'Visible','off');
set(handles.topoplot1,'Visible','off');


axes(handles.axes1);
cla;
axes(handles.axes3);
legend(handles.axes3,'off');
cla;
axes(handles.topoplot1);
cla;


set(handles.latency1_text,'Visible','off');
set(handles.latency1,'Visible','off');

set(handles.half_window_width_text,'Visible','off');
set(handles.half_window_width,'Visible','off');

set(handles.null_gen_panel,'Visible','off');
set(handles.gen_button,'Visible','off');
set(handles.save_button,'Visible','off');


guidata(hObject,handles);




% --- Executes on button press in reset2.
function reset2_Callback(hObject, eventdata, handles)
% hObject    handle to reset2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles.load2_data_all = [];

handles.pathnamelist2 = {};
handles.filenamelist2 = {};
handles.rec2 = {};

set(handles.load2_filename_list,'String',handles.filenamelist2);
set(handles.load2_filename_list,'Value', length(handles.filenamelist2));
set(handles.load2,'Value',1)

guidata(hObject, handles);

%%%%initiating values
%%%%initiating to-be-recorded variables
handles.within_cos_angle = [];
handles.betwen_cos_angle = [];
handles.template_latency = [];
handles.exp_latency = [];
handles.projection_exp = [];
handles.EEG_indicator = [];


%%%%initiate values
set(handles.load2_filename_list,'Value',0);
set(handles.current_time_load2,'String','0');
set(handles.latency1,'String','0');
set(handles.latency2,'String','0');
set(handles.latency3,'String','0');
set(handles.latency4,'String','0');
set(handles.latency5,'String','0');
set(handles.latency6,'String','0');
set(handles.latency7,'String','0');
set(handles.half_half_indicator,'Value',1);
set(handles.interleaved_indicator,'Value',0);
set(handles.random_indicator,'Value',0);


%%%%function selection
handles.angle_test_value = get(handles.angle_test,'Value');
handles.projection_test_value = get(handles.projection_test,'Value');
handles.angle_dynamics_value = get(handles.angle_dynamics,'Value');

%%%%initiating display
%%%%general for all 3 functions
set(handles.back_step1_load2,'Visible','off');
set(handles.back_step2_load2,'Visible','off');
set(handles.back_step3_load2,'Visible','off');

set(handles.forward_step1_load2,'Visible','off');
set(handles.forward_step2_load2,'Visible','off');
set(handles.forward_step3_load2,'Visible','off');

set(handles.current_time_load2,'Visible','off');

set(handles.axes2,'Visible','off');
set(handles.topoplot2,'Visible','off');



axes(handles.axes2);
cla;
axes(handles.topoplot2);
cla;

set(handles.latency2_text,'Visible','off');
set(handles.latency2,'Visible','off');
set(handles.latency3_text,'Visible','off');
set(handles.latency3,'Visible','off');
set(handles.latency4_text,'Visible','off');
set(handles.latency4,'Visible','off');
set(handles.latency5_text,'Visible','off');
set(handles.latency5,'Visible','off');
set(handles.latency6_text,'Visible','off');
set(handles.latency6,'Visible','off');
set(handles.latency7_text,'Visible','off');
set(handles.latency7,'Visible','off');

set(handles.half_window_width_text,'Visible','off');
set(handles.half_window_width,'Visible','off');

set(handles.null_gen_panel,'Visible','off');
set(handles.gen_button,'Visible','off');
set(handles.save_button,'Visible','off');

guidata(hObject,handles);


% --- Executes on button press in projection_test.
function projection_test_Callback(hObject, eventdata, handles)
% hObject    handle to projection_test (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of projection_test

setguiasopening(hObject)



% --- Executes on button press in angle_dynamics.
function angle_dynamics_Callback(hObject, eventdata, handles)
% hObject    handle to angle_dynamics (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of angle_dynamics

setguiasopening(hObject)


% --- Executes on button press in imp_ch_config.
function imp_ch_config_Callback(hObject, eventdata, handles)
% hObject    handle to imp_ch_config (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of imp_ch_config

if get(handles.imp_ch_config,'Value') == 1
    [filename,pathname] = uigetfile('*.txt', 'Load channel configuration file');
    handles.ch_pathname = pathname;
    handles.ch_filename = filename;
    if handles.ch_pathname == 0
        handles.ch_pathname =[];
    end
    if handles.ch_filename == 0
        handles.ch_filename = [];
    end
    if isempty(handles.ch_pathname) || isempty(handles.ch_filename)
        handles.ch_config = [];
        fprintf('please select a text file containing channel configuration');
    else
        handles.ch_config = dlmread([handles.ch_pathname handles.ch_filename]);
    end
else
    handles.ch_config = [];
end

if isempty(handles.ch_config)
    set(handles.imp_ch_config,'Value',0);
end

guidata(hObject,handles);
