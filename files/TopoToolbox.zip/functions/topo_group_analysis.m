function varargout = topo_group_analysis(varargin)
% TOPO_GROUP_ANALYSIS M-file for topo_group_analysis.fig
%      TOPO_GROUP_ANALYSIS, by itself, creates a new TOPO_GROUP_ANALYSIS or raises the existing
%      singleton*.
%
%      H = TOPO_GROUP_ANALYSIS returns the handle to a new TOPO_GROUP_ANALYSIS or the handle to
%      the existing singleton*.
%
%      TOPO_GROUP_ANALYSIS('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in TOPO_GROUP_ANALYSIS.M with the given input arguments.
%
%      TOPO_GROUP_ANALYSIS('Property','Value',...) creates a new TOPO_GROUP_ANALYSIS or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before topo_group_analysis_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to topo_group_analysis_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help topo_group_analysis

% Last Modified by GUIDE v2.5 29-Aug-2010 13:22:19

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
    'gui_Singleton',  gui_Singleton, ...
    'gui_OpeningFcn', @topo_group_analysis_OpeningFcn, ...
    'gui_OutputFcn',  @topo_group_analysis_OutputFcn, ...
    'gui_LayoutFcn',  [] , ...
    'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before topo_group_analysis is made visible.
function topo_group_analysis_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to topo_group_analysis (see VARARGIN)

% Choose default command line output for topo_group_analysis
handles.output = hObject;

%pixels
set( hObject, ...
    'Units', 'pixels' );

%get your display size
screenSize = get(0, 'ScreenSize');

%calculate the center of the display
position = get( hObject, ...
    'Position' );
position(1) = (screenSize(3)-position(3))/2;
position(2) = (screenSize(4)-position(4))/2;

%set(hObject,'Resize','On');

%center the window
set( hObject, ...
    'Position', position );

% Update handles structure
guidata(hObject, handles);

setguiasopening(hObject)

% UIWAIT makes topo_group_analysis wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = topo_group_analysis_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;

function setguiasopening(hObject)
% %%%%clear all store variables
% handles = [];
%%%%initiating new handles
handles = guidata(hObject);

%%%%initiating to-be-recorded variables
handles.filenamelist={};        % list of name of files for template
handles.pathnamelist={};        % list of path to files for template

handles.rec = {};               % list to record the number of files

%%%%reset file selections
set(handles.indi_list,'String',handles.filenamelist);

%%%%initiate values
set(handles.plot_width,'String','300');
set(handles.plot_sep,'Value',0);
set(handles.center_time,'String','0');
set(handles.half_window_width_stats,'String','10');
set(handles.t_value,'String','');
set(handles.degree_freedom,'String','');
set(handles.p_value,'String','');

%%%%function selection
handles.angle_test_value = get(handles.angle_test,'Value');
handles.projection_test_value = get(handles.projection_test,'Value');
handles.angle_dynamics_value = get(handles.angle_dynamics,'Value');

%%%%initiating display
%%%%general for all 3 functions
set(handles.plot_panel,'Visible','off');
set(handles.stats_panel,'Visible','off');
set(handles.axes1,'Visible','off');
set(handles.axes2,'Visible','off');

set(handles.gen_ttest,'String','t-test');
set(handles.stats_value_text,'String','t value');

axes(handles.axes1);
legend(handles.axes1,'off')
cla;
axes(handles.axes2);
legend(handles.axes2,'off')
cla;


%%%%set for specific functions
if handles.angle_test_value == 1
    handles.gen_button_string = {''};
elseif handles.projection_test_value == 1
    handles.gen_button_string = {'generate mean projection value waveform'};
elseif handles.angle_dynamics_value == 1
    handles.gen_button_string = {'generate mean angle measure waveform'};
end

set(handles.gen_button,'String',handles.gen_button_string);

guidata(hObject, handles);

% --- Executes on button press in gen_ttest.
function gen_ttest_Callback(hObject, eventdata, handles)
% hObject    handle to gen_ttest (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%%%%function selection
handles.angle_test_value = get(handles.angle_test,'Value');
handles.projection_test_value = get(handles.projection_test,'Value');
handles.angle_dynamics_value = get(handles.angle_dynamics,'Value');

set(handles.axes2,'Visible','on');

if handles.angle_test_value == 1
    angle_similarity_ttest(hObject, eventdata, handles)
elseif handles.projection_test_value == 1
    projection_ttest(hObject, eventdata, handles)
elseif handles.angle_dynamics_value == 1
    angle_dynamics_ttest(hObject,eventdata,handles)
end



%%%%internal function for paired t-test on angle similarity
function angle_similarity_ttest(hObject, eventdata, handles)
num_parti = length(handles.filenamelist);
for i = 1:num_parti
    eval(['temp_data = handles.indi_results.file',num2str(i),';']);
    temp.within(i) = temp_data.within_cos_angle;
    temp.between(i) = temp_data.between_cos_angle;
end
t_data = [temp.within-temp.between];
[h,p,ci,stats] = ttest(t_data);
set(handles.t_value,'String',num2str(stats.tstat));
set(handles.degree_freedom,'String',num2str(stats.df));
set(handles.p_value,'String',num2str(p));

%%%%ploting
within_cos_angle = mean(temp.within);
between_cos_angle = mean(temp.between);
within_cos_angle_sem = std(temp.within,1,2)/sqrt(length(temp.within));
between_cos_angle_sem = std(temp.between,1,2)/sqrt(length(temp.between));

axes(handles.axes2);
bar([within_cos_angle;between_cos_angle]);
set(gca,'XTickLabel',{'within_angle_measure';'between_angle_measure'})
hold on;
errorbar([within_cos_angle;between_cos_angle],[within_cos_angle_sem;between_cos_angle_sem],'+k','MarkerSize',1,'linewidth',1);
ylim([0 1]);
hold off;

ylabel('Angle measure');

%%%%internal function for paired t-test on projection
function projection_ttest(hObject, eventdata, handles)
num_parti = length(handles.filenamelist);
for i = 1:num_parti
    eval(['temp_data = handles.indi_results.file',num2str(i),';'])
    
    condition_num = length(fieldnames(temp_data.exp_latency));
    
    template_latency(:,i) = temp_data.template_latency;
    
    for n = 1:condition_num
        eval(['center_latency(n,i) = temp_data.exp_latency.con',num2str(n),';'])
        eval(['projection_exp(:,:,n,i) = temp_data.projection.file',num2str(n),';'])
    end
    
    sampling_frequency = temp_data.sampling_frequency;
    pre_trigger = temp_data.pre_trigger;
    post_trigger = temp_data.post_trigger;
end

if get(handles.p_ttest,'Value') == 1
    temp_file = projection_exp(:,:,handles.condition_selection,:);
    projection_exp = [];
    projection_exp = temp_file;
end

%%%%ploting only 300ms or the max before and after center latency
plot_width_def = str2num(get(handles.plot_width,'String'))*sampling_frequency/1000;
plot_width_max = min([min(min(center_latency))+pre_trigger post_trigger-max(max(center_latency))]);
if plot_width_max < plot_width_def
    plot_width = plot_width_max;
else
    plot_width = plot_width_def;
end

%%%%selecting only the to-be-ploted data to average
legend_name = {};
for i = 1:num_parti
    for n = 1:size(projection_exp,3)
        projection_exp_all(:,:,n,i) = projection_exp(:,[center_latency(n,i)+pre_trigger-plot_width:center_latency(n,i)+pre_trigger+plot_width],n,i);
        legend_name{end+1} = ['condition' num2str(n)];
    end
end

stats_center_time = round(str2num(get(handles.center_time,'String'))*sampling_frequency/1000);
stats_half_window_width = round(str2num(get(handles.half_window_width_stats,'String'))*sampling_frequency/1000);
projection_exp_time = transpose(squeeze(mean(projection_exp_all(:,[plot_width+1-stats_center_time-stats_half_window_width:plot_width+1-stats_center_time+stats_half_window_width],:,:),2)));

if size(projection_exp,3) == 2
    t_data = squeeze(projection_exp_time(:,1)-projection_exp_time(:,2));
    
    [h,p,ci,stats] = ttest(t_data);
    set(handles.t_value,'String',num2str(stats.tstat));
    set(handles.degree_freedom,'String',num2str(stats.df));
    set(handles.p_value,'String',num2str(p));
else
    [p,tbl,stats] = anova1(projection_exp_time,[],'off');
    set(handles.t_value,'String',tbl{2,5});
    set(handles.degree_freedom,'String',['(' num2str(tbl{2,3}) ',' num2str(tbl{3,3}) ')']);
    set(handles.p_value,'String',tbl{2,6});
end

%%%%ploting
mean_pro_exp = mean(projection_exp_time,1);
pro_exp_sem = std(projection_exp_time,1,1)/sqrt(length(projection_exp_time));


axes(handles.axes2);
bar(mean_pro_exp);
set(gca,'XTickLabel',legend_name)
hold on;
errorbar(mean_pro_exp,pro_exp_sem,'+k','MarkerSize',1,'linewidth',1);
%Ylim([0 1]);
hold off;

xlabel('Time (ms)');
ylabel('Projection value');

%%%%internal function for t-test on angle dynamics
function angle_dynamics_ttest(hObject,eventdata,handles)
num_parti = length(handles.filenamelist);
for i = 1:num_parti
    eval(['temp_data = handles.indi_results.file',num2str(i),';'])
    sampling_frequency = temp_data.sampling_frequency;
    pre_trigger = temp_data.pre_trigger;
    post_trigger = temp_data.post_trigger;
    center_latency(:,i) = temp_data.exp_latency;
    template_latency(:,i) = temp_data.template_latency;
    %within_cos_angle(:,:,i) = temp_data.within_cos_angle;
    within_cos_angle1(:,:,i) = temp_data.within_cos_angle1;
    within_cos_angle2(:,:,i) = temp_data.within_cos_angle2;
    between_cos_angle(:,:,i) = temp_data.between_cos_angle;
end

%%%%ploting only 300ms or the max before and after center latency
plot_width_def = str2num(get(handles.plot_width,'String'))*sampling_frequency/1000;
plot_width_max = min([min(center_latency)+pre_trigger post_trigger-max(center_latency)]);
if plot_width_max < plot_width_def
    plot_width = plot_width_max;
else
    plot_width = plot_width_def;
end

%%%%selecting only the to-be-ploted data to average
for i = 1:num_parti
    %within(:,:,i) = within_cos_angle(:,[center_latency(:,i)+pre_trigger-plot_width:center_latency(:,i)+pre_trigger+plot_width],i);
    within1(:,:,i) = within_cos_angle1(:,[template_latency(:,i)+pre_trigger-plot_width:template_latency(:,i)+pre_trigger+plot_width],i);
    within2(:,:,i) = within_cos_angle2(:,[center_latency(:,i)+pre_trigger-plot_width:center_latency(:,i)+pre_trigger+plot_width],i);
    within = (within1+within2)./2;
    between(:,:,i) = between_cos_angle(:,[center_latency(:,i)+pre_trigger-plot_width:center_latency(:,i)+pre_trigger+plot_width],i);
end

stats_center_time = round(str2num(get(handles.center_time,'String'))*sampling_frequency/1000);
stats_half_window_width = round(str2num(get(handles.half_window_width_stats,'String'))*sampling_frequency/1000);
within_cos_angle_time = squeeze(mean(within(:,[plot_width+1-stats_center_time-stats_half_window_width:plot_width+1-stats_center_time+stats_half_window_width],:),2));
between_cos_angle_time = squeeze(mean(between(:,[plot_width+1-stats_center_time-stats_half_window_width:plot_width+1-stats_center_time+stats_half_window_width],:),2));
t_data = [within_cos_angle_time-between_cos_angle_time];


[h,p,ci,stats] = ttest(t_data);
set(handles.t_value,'String',num2str(stats.tstat));
set(handles.degree_freedom,'String',num2str(stats.df));
set(handles.p_value,'String',num2str(p));

%%%%ploting
within_cos_angle = mean(within_cos_angle_time);
between_cos_angle = mean(between_cos_angle_time);
within_cos_angle_sem = std(within_cos_angle_time,1,1)/sqrt(length(within_cos_angle_time));
between_cos_angle_sem = std(between_cos_angle_time,1,1)/sqrt(length(between_cos_angle_time));

axes(handles.axes2);
bar([within_cos_angle;between_cos_angle]);
set(gca,'XTickLabel',{'within_angle_measure';'between_angle_measure'})
hold on;
errorbar([within_cos_angle;between_cos_angle],[within_cos_angle_sem;between_cos_angle_sem],'+k','MarkerSize',1,'linewidth',1);
ylim([0 1]);
hold off;

xlabel('Time (ms)');
ylabel('Angle measure');

function t_value_Callback(hObject, eventdata, handles)
% hObject    handle to t_value (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of t_value as text
%        str2double(get(hObject,'String')) returns contents of t_value as a double


% --- Executes during object creation, after setting all properties.
function t_value_CreateFcn(hObject, eventdata, handles)
% hObject    handle to t_value (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function degree_freedom_Callback(hObject, eventdata, handles)
% hObject    handle to degree_freedom (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of degree_freedom as text
%        str2double(get(hObject,'String')) returns contents of degree_freedom as a double


% --- Executes during object creation, after setting all properties.
function degree_freedom_CreateFcn(hObject, eventdata, handles)
% hObject    handle to degree_freedom (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function p_value_Callback(hObject, eventdata, handles)
% hObject    handle to p_value (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of p_value as text
%        str2double(get(hObject,'String')) returns contents of p_value as a double


% --- Executes during object creation, after setting all properties.
function p_value_CreateFcn(hObject, eventdata, handles)
% hObject    handle to p_value (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function center_time_Callback(hObject, eventdata, handles)
% hObject    handle to center_time (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of center_time as text
%        str2double(get(hObject,'String')) returns contents of center_time as a double


% --- Executes during object creation, after setting all properties.
function center_time_CreateFcn(hObject, eventdata, handles)
% hObject    handle to center_time (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function half_window_width_stats_Callback(hObject, eventdata, handles)
% hObject    handle to half_window_width_stats (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of half_window_width_stats as text
%        str2double(get(hObject,'String')) returns contents of half_window_width_stats as a double


% --- Executes during object creation, after setting all properties.
function half_window_width_stats_CreateFcn(hObject, eventdata, handles)
% hObject    handle to half_window_width_stats (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function plot_width_Callback(hObject, eventdata, handles)
% hObject    handle to plot_width (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of plot_width as text
%        str2double(get(hObject,'String')) returns contents of plot_width as a double


% --- Executes during object creation, after setting all properties.
function plot_width_CreateFcn(hObject, eventdata, handles)
% hObject    handle to plot_width (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in plot_sep.
function plot_sep_Callback(hObject, eventdata, handles)
% hObject    handle to plot_sep (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of plot_sep


% --- Executes on button press in gen_button.
function gen_button_Callback(hObject, eventdata, handles)
% hObject    handle to gen_button (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

handles.angle_test_value = get(handles.angle_test,'Value');
handles.projection_test_value = get(handles.projection_test,'Value');
handles.angle_dynamics_value = get(handles.angle_dynamics,'Value');

set(handles.axes1,'Visible','on');

if handles.projection_test_value == 1
    plot_projection(hObject, eventdata, handles)
elseif handles.angle_dynamics_value == 1
    plot_dynamics(hObject, eventdata, handles)
end


%%%%internal function for plotiing projection value waveform
function plot_projection(hObject, eventdata, handles)
num_parti = length(handles.filenamelist);
for i = 1:num_parti
    eval(['temp_data = handles.indi_results.file',num2str(i),';'])
    
    condition_num = length(fieldnames(temp_data.exp_latency));
    if condition_num == 2
        set(handles.p_ttest,'Visible','off');
    elseif condition_num > 2
        set(handles.gen_ttest,'String','ANOVA');
        set(handles.stats_value_text,'String','F value');
        set(handles.p_ttest,'Visible','on');
    end
    
    
    template_latency(:,i) = temp_data.template_latency;
    
    for n = 1:condition_num
        eval(['center_latency(n,i) = temp_data.exp_latency.con',num2str(n),';'])
        eval(['projection_exp(:,:,n,i) = temp_data.projection.file',num2str(n),';'])
    end
    
    sampling_frequency = temp_data.sampling_frequency;
    pre_trigger = temp_data.pre_trigger;
    post_trigger = temp_data.post_trigger;
end

%%%%ploting only 300ms or the max before and after center latency
plot_width_def = str2num(get(handles.plot_width,'String'))*sampling_frequency/1000;
plot_width_max = min([min(min(center_latency))+pre_trigger post_trigger-max(max(center_latency))]);
if plot_width_max < plot_width_def
    plot_width = plot_width_max;
else
    plot_width = plot_width_def;
end

%%%%selecting only the to-be-ploted data to average
for i = 1:num_parti
    for n = 1:condition_num
        projection_exp_all(:,:,n,i) = projection_exp(:,[center_latency(n,i)+pre_trigger-plot_width:center_latency(n,i)+pre_trigger+plot_width],n,i);
    end
end

projection_exp_mean = mean(projection_exp_all,4);
projection_exp_sem = std(projection_exp_all,1,4)./sqrt(num_parti);

if get(handles.plot_sep,'Value') == 0
    axes(handles.axes1);
else
    figure;
end
t = [-plot_width*1000/sampling_frequency:1000/sampling_frequency:plot_width*1000/sampling_frequency];
legend_name = {};
colorlist = {'y','r','b','k','c','g'};
for n = 1:condition_num
    plot(t,projection_exp_mean(:,:,n),colorlist{n},'linewidth',3);
    hold on;
    legend_name{end+1} = ['condition' num2str(n)];
end

legend(legend_name);

colorlist = {'--y','--r','--b','--k','--c','--g'};
for n = 1:condition_num
    plot(t,projection_exp_mean(:,:,n)-projection_exp_sem(:,:,n),colorlist{n},t,projection_exp_mean(:,:,n)+projection_exp_sem(:,:,n),colorlist{n});
end

hold off;

xlabel('Time (ms)');
ylabel('Projection value');


%%%%internal function for plot angle dynamics
function plot_dynamics(hObject, eventdata, handles)
num_parti = length(handles.filenamelist);
for i = 1:num_parti
    eval(['temp_data = handles.indi_results.file',num2str(i),';'])
    sampling_frequency = temp_data.sampling_frequency;
    pre_trigger = temp_data.pre_trigger;
    post_trigger = temp_data.post_trigger;
    center_latency(:,i) = temp_data.exp_latency;
    template_latency(:,i) = temp_data.template_latency;
    %within_cos_angle(:,:,i) = temp_data.within_cos_angle;
    within_cos_angle1(:,:,i) = temp_data.within_cos_angle1;
    within_cos_angle2(:,:,i) = temp_data.within_cos_angle2;
    between_cos_angle(:,:,i) = temp_data.between_cos_angle;
end

%%%%ploting only 300ms or the max before and after center latency
plot_width_def = str2num(get(handles.plot_width,'String'))*sampling_frequency/1000;
plot_width_max = min([min(center_latency)+pre_trigger post_trigger-max(center_latency)]);
if plot_width_max < plot_width_def
    plot_width = plot_width_max;
else
    plot_width = plot_width_def;
end

%%%%selecting only the to-be-ploted data to average
for i = 1:num_parti
    %within(:,:,i) = within_cos_angle(:,[center_latency(:,i)+pre_trigger-plot_width:center_latency(:,i)+pre_trigger+plot_width],i);
    within1(:,:,i) = within_cos_angle1(:,[template_latency(:,i)+pre_trigger-plot_width:template_latency(:,i)+pre_trigger+plot_width],i);
    within2(:,:,i) = within_cos_angle2(:,[center_latency(:,i)+pre_trigger-plot_width:center_latency(:,i)+pre_trigger+plot_width],i);
    within = (within1+within2)./2;
    between(:,:,i) = between_cos_angle(:,[center_latency(:,i)+pre_trigger-plot_width:center_latency(:,i)+pre_trigger+plot_width],i);
end

within_cos_angle_mean = mean(within,3);
within_cos_angle_sem = std(within,1,3)./sqrt(num_parti);
between_cos_angle_mean = mean(between,3);
between_cos_angle_sem = std(between,1,3)./sqrt(num_parti);

if get(handles.plot_sep,'Value') == 0
    axes(handles.axes1);
else
    figure;
end

t = [-plot_width*1000/sampling_frequency:1000/sampling_frequency:plot_width*1000/sampling_frequency];
plot(t,within_cos_angle_mean,'y',t,between_cos_angle_mean,'r');
hold on;
for counter = 1:size(within_cos_angle_mean,2)
    line([(counter-plot_width-1)*1000/sampling_frequency (counter-plot_width-1)*1000/sampling_frequency],[within_cos_angle_mean(:,counter)-within_cos_angle_sem(:,counter) within_cos_angle_mean(:,counter)+within_cos_angle_sem(:,counter)],'Color','k','linewidth',2);
end
for counter = 1:size(between_cos_angle_mean,2)
    line([(counter-plot_width-1)*1000/sampling_frequency (counter-plot_width-1)*1000/sampling_frequency],[between_cos_angle_mean(:,counter)-between_cos_angle_sem(:,counter) between_cos_angle_mean(:,counter)+between_cos_angle_sem(:,counter)],'Color','g','linewidth',2);
end
t = [-plot_width*1000/sampling_frequency:1000/sampling_frequency:plot_width*1000/sampling_frequency];
plot(t,within_cos_angle_mean,'y',t,between_cos_angle_mean,'r');
legend('within angle measure','between angle measure');
hold off;

xlabel('Time (ms)');
ylabel('Angle measure');

% --- Executes on selection change in indi_list.
function indi_list_Callback(hObject, eventdata, handles)
% hObject    handle to indi_list (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns indi_list contents as cell array
%        contents{get(hObject,'Value')} returns selected item from indi_list


% --- Executes during object creation, after setting all properties.
function indi_list_CreateFcn(hObject, eventdata, handles)
% hObject    handle to indi_list (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in remove_button.
function remove_button_Callback(hObject, eventdata, handles)
% hObject    handle to remove_button (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

ss=get(handles.indi_list,'Value');

handles.rec(ss:end-1)=handles.rec(ss+1:end);
handles.rec=handles.rec(1:end-1);
handles.filenamelist(ss:end-1)=handles.filenamelist(ss+1:end);
handles.filenamelist=handles.filenamelist(1:end-1);
handles.pathnamelist(ss:end-1)=handles.pathnamelist(ss+1:end);
handles.pathnamelist=handles.pathnamelist(1:end-1);
if length(handles.filenamelist)<ss && ss~=1
    ss=ss-1;
end
set(handles.indi_list,'Value',ss);
set(handles.indi_list,'String',handles.filenamelist);
guidata(hObject,handles);
if length(handles.filenamelist)==0
    reset_button_Callback(hObject, eventdata, handles);
end

% --- Executes on button press in reset_button.
function reset_button_Callback(hObject, eventdata, handles)
% hObject    handle to reset_button (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles.pathnamelist = {};
handles.filenamelist = {};
handles.rec = {};

set(handles.indi_list,'String',handles.filenamelist);
set(handles.indi_list,'Value', length(handles.filenamelist));
set(handles.load_indi,'Value',1)

guidata(hObject, handles);


%%%%initiate values
set(handles.plot_width,'String','300');
set(handles.plot_sep,'Value',0);
set(handles.center_time,'String','0');
set(handles.half_window_width_stats,'String','10');
set(handles.t_value,'String','');
set(handles.degree_freedom,'String','');
set(handles.p_value,'String','');

%%%%function selection
handles.angle_test_value = get(handles.angle_test,'Value');
handles.projection_test_value = get(handles.projection_test,'Value');
handles.angle_dynamics_value = get(handles.angle_dynamics,'Value');

%%%%initiating display
%%%%general for all 3 functions
set(handles.plot_panel,'Visible','off');
set(handles.stats_panel,'Visible','off');
set(handles.axes1,'Visible','off');
set(handles.axes2,'Visible','off');

set(handles.gen_ttest,'String','t-test');
set(handles.stats_value_text,'String','t value');

axes(handles.axes1);
legend(handles.axes1,'off')
cla;
axes(handles.axes2);
legend(handles.axes2,'off')
cla;


%%%%set for specific functions
if handles.angle_test_value == 1
    handles.gen_button_string = {''};
elseif handles.projection_test_value == 1
    handles.gen_button_string = {'generate mean projection value waveform'};
elseif handles.angle_dynamics_value == 1
    handles.gen_button_string = {'generate mean angle measure waveform'};
end

set(handles.gen_button,'String',handles.gen_button_string);

guidata(hObject, handles);

% --- Executes on selection change in load_indi.
function load_indi_Callback(hObject, eventdata, handles)
% hObject    handle to load_indi (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns load_indi contents as cell array
%        contents{get(hObject,'Value')} returns selected item from load_indi
handles.load_indi_value = get(handles.load_indi,'Value');
handles.load_indi_string = get(handles.load_indi,'String');
if handles.load_indi_value == 2 %%%%load .mat file
    [filename, pathname] = uigetfile('*.mat', 'File to load');
    handles.pathname = pathname;
    handles.filename = filename;
    handles.filenamelist{end+1}=filename;  % name of all files
    handles.pathnamelist{end+1}=pathname;  % path of all files
    %%%%update GUI
    set(handles.indi_list,'String',handles.filenamelist);
    set(handles.indi_list,'Value', length(handles.filenamelist));
    set(handles.load_indi,'Value',1)
    
    handles.rec{length(handles.filenamelist)}={};
    
    guidata(hObject,handles);
elseif handles.load_indi_value == 3 %%%%load files in a directory
    pathname=uigetdir('*.*','Directory to load');
    if pathname~=0
        if exist(pathname,'dir')
            files=dir(pathname);
            for k=3:length(files)
                handles.pathname=[pathname '/'];
                handles.filename=files(k).name;
                handles.filenamelist{end+1}=files(k).name;
                handles.pathnamelist{end+1}=[pathname '/'];
                handles.rec{length(handles.filenamelist)}={};
            end
            set(handles.indi_list,'String',handles.filenamelist);
            set(handles.indi_list,'Value', length(handles.filenamelist));
            guidata(hObject,handles);
        end
    end
end

set(handles.load_indi,'Value',1);


% --- Executes during object creation, after setting all properties.
function load_indi_CreateFcn(hObject, eventdata, handles)
% hObject    handle to load_indi (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in angle_test.
function angle_test_Callback(hObject, eventdata, handles)
% hObject    handle to angle_test (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of angle_test

setguiasopening(hObject)


% --- Executes on button press in projection_test.
function projection_test_Callback(hObject, eventdata, handles)
% hObject    handle to projection_test (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of projection_test

setguiasopening(hObject)


% --- Executes on button press in angle_dynamics.
function angle_dynamics_Callback(hObject, eventdata, handles)
% hObject    handle to angle_dynamics (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of angle_dynamics

setguiasopening(hObject)


% --- Executes on button press in load_button.
function load_button_Callback(hObject, eventdata, handles)
% hObject    handle to load_button (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
indi_list = get(handles.indi_list,'String');

handles.angle_test_value = get(handles.angle_test,'Value');
handles.projection_test_value = get(handles.projection_test,'Value');
handles.angle_dynamics_value = get(handles.angle_dynamics,'Value');

%%%%loading data
for i = 1:length(indi_list)
    eval(['handles.indi_results.file',num2str(i),' = cell2mat(struct2cell(load([handles.pathnamelist{i} handles.filenamelist{i}])));'])
end

%%%%initiating appearence

set(handles.stats_panel,'Visible','on');

if handles.angle_test_value == 1
    set(handles.center_time_text,'Visible','off');
    set(handles.center_time,'Visible','off');
    set(handles.half_window_width_stats_text,'Visible','off');
    set(handles.half_window_width_stats,'Visible','off');
elseif handles.projection_test_value == 1
    set(handles.plot_panel,'Visible','on');
    set(handles.center_time_text,'Visible','on');
    set(handles.center_time,'Visible','on');
    set(handles.half_window_width_stats_text,'Visible','on');
    set(handles.half_window_width_stats,'Visible','on');
    
    condition_num = length(fieldnames(handles.indi_results.file1.exp_latency));
    if condition_num == 2
        set(handles.p_ttest,'Visible','off');
    elseif condition_num > 2
        set(handles.gen_ttest,'String','ANOVA');
        set(handles.stats_value_text,'String','F value');
        set(handles.p_ttest,'Value',0);
        set(handles.p_ttest,'Visible','on');
    end
    
elseif handles.angle_dynamics_value == 1;
    set(handles.plot_panel,'Visible','on');
    set(handles.center_time_text,'Visible','on');
    set(handles.center_time,'Visible','on');
    set(handles.half_window_width_stats_text,'Visible','on');
    set(handles.half_window_width_stats,'Visible','on');
end

guidata(hObject, handles);


% --- Executes on button press in p_ttest.
function p_ttest_Callback(hObject, eventdata, handles)
% hObject    handle to p_ttest (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of p_ttest

if get(handles.p_ttest,'Value') == 1
    prompt = {'Selection conditions for post-hoc t-test (example 1,3): '}; % prompt for the filename
    dlg_title = 'condition numbers'; % title of the input dialog box
    num_lines = 1; % number of input lines
    defaultinput = {''}; % default filename
    %handles.condition_selection = str2num(inputdlg(prompt,dlg_title,num_lines,defaultinput));
    condition_selection = cell2mat(inputdlg(prompt,dlg_title,num_lines,defaultinput));
    temp1 = str2num(condition_selection(1));
    temp2 = str2num(condition_selection(end));
    
    handles.condition_selection = [temp1,temp2];
    
    guidata(hObject, handles);
    
    set(handles.gen_ttest,'String','t-test');
    set(handles.stats_value_text,'String','t value');
    
else
    set(handles.gen_ttest,'String','ANOVA');
    set(handles.stats_value_text,'String','F value');
    
end
