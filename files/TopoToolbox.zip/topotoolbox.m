function varargout = topotoolbox(varargin)
% TOPOTOOLBOX M-file for topotoolbox.fig
%      TOPOTOOLBOX, by itself, creates a new TOPOTOOLBOX or raises the existing
%      singleton*.
%
%      H = TOPOTOOLBOX returns the handle to a new TOPOTOOLBOX or the handle to
%      the existing singleton*.
%
%      TOPOTOOLBOX('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in TOPOTOOLBOX.M with the given input arguments.
%
%      TOPOTOOLBOX('Property','Value',...) creates a new TOPOTOOLBOX or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before topotoolbox_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to topotoolbox_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help topotoolbox

% Last Modified by GUIDE v2.5 30-Aug-2010 08:43:30

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @topotoolbox_OpeningFcn, ...
                   'gui_OutputFcn',  @topotoolbox_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before topotoolbox is made visible.
function topotoolbox_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to topotoolbox (see VARARGIN)

% Choose default command line output for topotoolbox
handles.output = hObject;

axes(handles.axes1);
image1 = imread('topomethod.tif');
bkg = double([image1(1,1,1), image1(1,1,2), image1(1,1,3),]);
bkg = bkg ./ 255.0;
set(hObject,'Color',bkg);
set(handles.titletext,'BackgroundColor',bkg);
set(handles.uipanel1,'BackgroundColor',bkg);
image(image1);
axis off;
axis image;

%pixels
set( hObject, ...
    'Units', 'pixels' );

%get your display size
screenSize = get(0, 'ScreenSize');

%calculate the center of the display
position = get( hObject, ...
    'Position' );
position(1) = (screenSize(3)-position(3))/2-position(3);
position(2) = (screenSize(4)-position(4))/2+position(4);

%set(hObject,'Resize','On');

%center the window
set( hObject, ...
    'Position', position );

% image1 = imread('topomethod.tif');
% image(image1,'parent',handles.axes1);
% colormap(gray);

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes topotoolbox wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = topotoolbox_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in indi_analysis.
function indi_analysis_Callback(hObject, eventdata, handles)
% hObject    handle to indi_analysis (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

topo_individual_analysis;


% --- Executes on button press in group_analysis.
function group_analysis_Callback(hObject, eventdata, handles)
% hObject    handle to group_analysis (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

topo_group_analysis;

